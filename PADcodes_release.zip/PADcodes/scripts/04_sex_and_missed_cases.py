# =============================================================================
# 04_sex_and_missed_cases.py
# (1) Sex-only baseline; (2) questionnaire-only model with the two sexual-function
# items removed; (3) within-sex discrimination of the full system and of the
# questionnaire-only model; (4) missed (false-negative) versus detected PD
# patients: sex, questionnaire item count, age and estimated disease duration.
# Uses the PADS JSON files and raw_predictions.pkl; the questionnaire-only model
# is refitted with the same folds (~1-2 min). Output: <RUN_DIR>/sex_fn_check.json
# =============================================================================
import os, re, json, pickle, zipfile, subprocess, warnings
from glob import glob
import numpy as np
warnings.filterwarnings("ignore")

RUN_DIR   = "/content/drive/MyDrive/Parkinson/pads_final_6ch"
ZIP_NAME  = "pads-parkinsons-disease-smartwatch-dataset-1.0.0.zip"
META_DIR  = "/content/pads_meta"
RANDOM_STATE = 42
N_FOLDS = 10

# ------------------------------------------------------------------ Drive
try:
    from google.colab import drive
    if not os.path.ismount("/content/drive"):
        drive.mount("/content/drive")
except Exception as e:
    print(f"(not on Colab or Drive unavailable: {e})")

from scipy.stats import wilcoxon, mannwhitneyu, fisher_exact
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_curve, roc_auc_score, balanced_accuracy_score, recall_score

# ------------------------------------------------------------------ data (JSON files only)
def find_zip():
    for p in [f"/content/drive/MyDrive/Parkinson/{ZIP_NAME}", f"/content/drive/MyDrive/{ZIP_NAME}",
              f"/content/{ZIP_NAME}", f"./{ZIP_NAME}"]:
        if os.path.exists(p):
            return p
    if os.path.exists("/content/drive"):
        r = subprocess.getoutput(f"find /content/drive -name '{ZIP_NAME}' -type f 2>/dev/null | head -1").strip()
        if r:
            return r
    raise FileNotFoundError(f"{ZIP_NAME} not found")

if not glob(f"{META_DIR}/**/patient_*.json", recursive=True):
    zp = find_zip()
    print(f"Extracting JSON files: {zp}")
    with zipfile.ZipFile(zp) as z:
        members = [m for m in z.namelist()
                   if re.search(r"(patient_[^/]*\.json|questionnaire_response_[^/]*\.json)$", m)]
        z.extractall(META_DIR, members=members)

PD_CONDITIONS = {"parkinson", "parkinsons", "parkinson's", "parkinson disease",
                 "parkinsons disease", "parkinson's disease"}
HC_CONDITIONS = {"healthy", "healthy control", "healthy controls", "control"}
def _norm(s):
    return " ".join(str(s).strip().lower().replace("\u2019", "'").split())
def label_of(c):
    c = _norm(c)
    return 1 if c in PD_CONDITIONS else (0 if c in HC_CONDITIONS else -1)

info, all_keys = {}, set()
for pf in sorted(glob(f"{META_DIR}/**/patient_*.json", recursive=True)):
    d = json.load(open(pf))
    all_keys |= set(d.keys())
    lbl = label_of(d.get("condition", ""))
    if lbl < 0:
        continue
    info[str(d["id"])] = {"label": lbl, "gender": str(d.get("gender", "")).lower(),
                          "age": d.get("age"), "age_dx": d.get("age_at_diagnosis")}

print("=" * 74)
print("1) PATIENT-RECORD FIELDS")
print("=" * 74)
print("   " + ", ".join(sorted(all_keys)))
hits = [k for k in all_keys if re.search(r"medic|levodopa|dopa|on_off|onoff|hoehn|yahr|updrs|stage|treat", k, re.I)]
print(f"   medication / disease-stage fields: {hits if hits else 'NONE'}")

items_text, nms = {}, {}
for qf in sorted(glob(f"{META_DIR}/**/questionnaire_response_*.json", recursive=True)):
    q = json.load(open(qf)); pid = str(q.get("subject_id", ""))
    if pid not in info:
        continue
    ans = [0] * 30
    for it in q.get("item", []):
        try:
            i = int(it.get("link_id", "99")) - 1
        except Exception:
            continue
        if 0 <= i < 30:
            ans[i] = 1 if it.get("answer") else 0
            items_text.setdefault(i, str(it.get("text", "")))
    nms[pid] = ans

pids   = np.array(sorted(info))
y      = np.array([info[p]["label"] for p in pids])
X_nms  = np.array([nms.get(p, [0] * 30) for p in pids], dtype=np.float32)
male   = np.array([1 if info[p]["gender"] == "male" else 0 for p in pids])
age    = np.array([float(info[p]["age"]) if info[p]["age"] is not None else np.nan for p in pids])
agedx  = np.array([float(info[p]["age_dx"]) if isinstance(info[p]["age_dx"], (int, float)) else np.nan for p in pids])
dur    = np.where(y == 1, age - agedx, np.nan)
dur    = np.where(dur >= 0, dur, np.nan)
assert (int((y == 1).sum()), int((y == 0).sum())) == (276, 79), "expected 276/79"

print("\n" + "=" * 74)
print("2) DEMOGRAPHICS")
print("=" * 74)
for g, nm in [(1, "PD"), (0, "HC")]:
    m = y == g
    print(f"   {nm}: n={m.sum()}  age {np.nanmean(age[m]):.1f} ± {np.nanstd(age[m], ddof=1):.1f}  "
          f"male {male[m].sum()}/{m.sum()} ({100*male[m].mean():.0f}%)")
print("   reported: PD 195/276 male | HC 29/79 male")

# ------------------------------------------------------------------ fold structure + published predictions
R = pickle.load(open(f"{RUN_DIR}/raw_predictions.pkl", "rb"))
all_true = np.asarray(R["all_true"]); all_prob = np.asarray(R["all_prob"]); all_pred = np.asarray(R["all_pred"])
outer = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_STATE)
inner = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
folds = list(outer.split(pids, y))
order = np.concatenate([te for _, te in folds])
assert np.array_equal(y[order], all_true), "rebuilt folds do not match the published all_true order"
print("\n   [check] rebuilt folds match the published prediction order")

def youden(yt, s):
    f, t, th = roc_curve(yt, s)
    return float(th[np.argmax(t - f)])

def nms_model():
    return Pipeline([("sc", StandardScaler()),
                     ("lr", LogisticRegression(C=1.0, class_weight="balanced", max_iter=1000,
                                               random_state=RANDOM_STATE))])

def run_cv(X):
    """A3 protocol: fit on the outer training fold, Youden threshold from inner 5-fold OOF scores, apply to the test fold."""
    ba, prob = [], np.zeros(len(y)); pred = np.zeros(len(y), int)
    for tr, te in folds:
        m = nms_model().fit(X[tr], y[tr])
        oof = cross_val_predict(nms_model(), X[tr], y[tr], cv=inner, method="predict_proba")[:, 1]
        th = youden(y[tr], oof)
        p = m.predict_proba(X[te])[:, 1]
        prob[te] = p; pred[te] = (p >= th).astype(int)
        ba.append(balanced_accuracy_score(y[te], pred[te]) * 100)
    return np.array(ba), prob, pred

# ------------------------------------------------------------------ 3) sex only
rule_se = 100 * male[y == 1].mean(); rule_sp = 100 * (1 - male[y == 0].mean()); rule_ba = (rule_se + rule_sp) / 2
ba_sex, _, _ = run_cv(male.reshape(-1, 1).astype(np.float32))
print("\n" + "=" * 74)
print("3) SEX ONLY")
print("=" * 74)
print(f"   pooled rule (male -> PD): BA {rule_ba:.2f}%  Se {rule_se:.2f}%  Sp {rule_sp:.2f}%  (reported: 66.97 / 70.65 / 63.29)")
print(f"   same CV protocol:         BA {ba_sex.mean():.2f} ± {ba_sex.std():.2f}%")

# ------------------------------------------------------------------ 4) A3 reproduction + sexual-function items removed
ba_a3, prob_a3, pred_a3 = run_cv(X_nms)
pub_a3 = np.asarray(R["results"]["A3_NMS_Only"]["bal_acc"]) * 100
same = np.allclose(ba_a3, pub_a3, atol=1e-6)
print("\n" + "=" * 74)
print("4) QUESTIONNAIRE ONLY (A3) AND WITHOUT THE SEXUAL-FUNCTION ITEMS")
print("=" * 74)
print(f"   A3 reproduced: {ba_a3.mean():.2f} ± {ba_a3.std():.2f}%   published: {pub_a3.mean():.2f}%   "
      f"identical per fold: {'YES' if same else 'NO (scikit-learn version may differ)'}")
sex_items = [i for i, t in items_text.items() if re.search(r"\bsex", t, re.I)]
print(f"   sexual-function items ({len(sex_items)}):")
for i in sex_items:
    print(f"      item {i+1:02d}: {items_text[i]}")
assert sex_items, "no item text contains 'sex' — check the item list manually"
keep = [i for i in range(30) if i not in sex_items]
ba_ns, prob_ns, _ = run_cv(X_nms[:, keep])
try:
    Wns, pns = wilcoxon(ba_a3, ba_ns)
except ValueError:
    Wns, pns = 0.0, 1.0
print(f"   {30-len(sex_items)} items: {ba_ns.mean():.2f} ± {ba_ns.std():.2f}%  "
      f"(diff {ba_ns.mean()-ba_a3.mean():+.2f} pp; W = {Wns:.1f}, p = {pns:.3f})")

# ------------------------------------------------------------------ 5) within-sex discrimination
m_o, s_o = male[order], None
def within(mask_sex):
    idx = order[male[order] == mask_sex]
    pos = np.isin(order, idx)
    yt, pr, pd_ = all_true[pos], all_prob[pos], all_pred[pos]
    return (roc_auc_score(yt, pr) * 100, recall_score(yt, pd_, pos_label=1) * 100,
            recall_score(yt, pd_, pos_label=0) * 100, int(pos.sum()))
auc_m, se_m, sp_m, n_m = within(1)
auc_f, se_f, sp_f, n_f = within(0)
auc3_m = roc_auc_score(y[male == 1], prob_a3[male == 1]) * 100
auc3_f = roc_auc_score(y[male == 0], prob_a3[male == 0]) * 100
print("\n" + "=" * 74)
print("5) WITHIN SEX (pooled OOF)")
print("=" * 74)
print(f"   A1 full system  male   n={n_m}: AUC {auc_m:.1f}%  Se {se_m:.1f}%  Sp {sp_m:.1f}%")
print(f"   A1 full system  female n={n_f}: AUC {auc_f:.1f}%  Se {se_f:.1f}%  Sp {sp_f:.1f}%")
print(f"   A3 NMS only     male AUC {auc3_m:.1f}%   female AUC {auc3_f:.1f}%")
print(f"   (overall pooled AUC {roc_auc_score(all_true, all_prob)*100:.2f}%)")

# ------------------------------------------------------------------ 6) missed vs detected
pdm = all_true == 1
fn_ids = order[pdm & (all_pred == 0)]; tp_ids = order[pdm & (all_pred == 1)]
cnt = X_nms.sum(axis=1)
def med_iqr(v):
    v = v[~np.isnan(v)]
    return np.median(v), np.percentile(v, 25), np.percentile(v, 75), len(v)
fn_f = int((male[fn_ids] == 0).sum()); tp_f = int((male[tp_ids] == 0).sum())
_, p_sex = fisher_exact([[fn_f, len(fn_ids) - fn_f], [tp_f, len(tp_ids) - tp_f]])
def mw(a, b):
    a, b = a[~np.isnan(a)], b[~np.isnan(b)]
    return mannwhitneyu(a, b, alternative="two-sided").pvalue
p_nms = mw(cnt[fn_ids].astype(float), cnt[tp_ids].astype(float))
p_age = mw(age[fn_ids], age[tp_ids])
p_dur = mw(dur[fn_ids], dur[tp_ids])
fnN, tpN = med_iqr(cnt[fn_ids].astype(float)), med_iqr(cnt[tp_ids].astype(float))
fnA, tpA = med_iqr(age[fn_ids]), med_iqr(age[tp_ids])
fnD, tpD = med_iqr(dur[fn_ids]), med_iqr(dur[tp_ids])
print("\n" + "=" * 74)
print(f"6) MISSED ({len(fn_ids)}) vs DETECTED ({len(tp_ids)}) PD PATIENTS")
print("=" * 74)
print(f"   female share      {100*fn_f/len(fn_ids):.0f}% vs {100*tp_f/len(tp_ids):.0f}%   Fisher p = {p_sex:.3f}")
print(f"   items endorsed    {fnN[0]:.0f} ({fnN[1]:.0f}-{fnN[2]:.0f}) vs {tpN[0]:.0f} ({tpN[1]:.0f}-{tpN[2]:.0f})   p = {p_nms:.3g}")
print(f"   age               {fnA[0]:.0f} vs {tpA[0]:.0f}   p = {p_age:.3f}")
print(f"   disease duration  {fnD[0]:.1f} vs {tpD[0]:.1f} years  (n={fnD[3]}/{tpD[3]})   p = {p_dur:.3f}")
assert (len(fn_ids), len(tp_ids)) == (41, 235), "expected 41/235"

out = {"json_keys": sorted(all_keys), "medication_or_stage_keys": hits,
       "sex_only": {"rule_ba": rule_ba, "rule_se": rule_se, "rule_sp": rule_sp,
                    "cv_ba_mean": float(ba_sex.mean()), "cv_ba_sd": float(ba_sex.std())},
       "A3": {"reproduced_fold_ba": ba_a3.tolist(), "published_fold_ba": pub_a3.tolist(), "bit_identical": bool(same)},
       "A3_without_sex_items": {"items": [i + 1 for i in sex_items], "fold_ba": ba_ns.tolist(),
                                "W": float(Wns), "p": float(pns)},
       "within_sex": {"A1": {"male": [auc_m, se_m, sp_m, n_m], "female": [auc_f, se_f, sp_f, n_f]},
                      "A3_auc": {"male": auc3_m, "female": auc3_f}},
       "missed_vs_detected": {"n": [len(fn_ids), len(tp_ids)], "female": [fn_f, tp_f], "p_sex": p_sex,
                              "nms_median_iqr": [fnN[:3], tpN[:3]], "p_nms": p_nms,
                              "age_median": [fnA[0], tpA[0]], "p_age": p_age,
                              "duration_median": [fnD[0], tpD[0]], "p_duration": p_dur}}
json.dump(out, open(f"{RUN_DIR}/sex_fn_check.json", "w"), indent=2, default=float)
print(f"\nSaved: {RUN_DIR}/sex_fn_check.json")
