# =============================================================================
# 02_dispersion_tests.py
# Is the lower cross-fold SD of specificity with the motion branch (A1 vs A3)
# more than sampling variability? Median-centred Levene test, Fligner-Killeen
# test, paired fold-level bootstrap of 1 - SD(A1)/SD(A3) (10,000 resamples)
# and leave-one-fold-out recomputation. Reads raw_predictions.pkl from
# 01_main_pipeline.py; no model is refitted (~10 s).
# Output: <RUN_DIR>/dispersion_check.json
# =============================================================================
import os, json, pickle, numpy as np
from scipy import stats

RUN_DIR   = "/content/drive/MyDrive/Parkinson/pads_final_6ch"
N_BOOT    = 10000
BOOT_SEED = 42

# values reported in the manuscript (reproduction targets)
REPORTED = {"levene_p": 1.00, "fligner_p": 0.46,
            "boot_lo": -83.7, "boot_hi": 54.8,
            "sd_a1": 9.76, "sd_a3": 14.84, "reduction_pct": 34}

# ----------------------------------------------------------------- data
if not os.path.exists("/content/drive/MyDrive"):
    try:
        from google.colab import drive; drive.mount("/content/drive")
    except Exception as e:
        print(f"(Drive not mounted: {e})")

pkl = f"{RUN_DIR}/raw_predictions.pkl"
assert os.path.exists(pkl), f"Not found: {pkl}"
R = pickle.load(open(pkl, "rb"))["results"]

A1 = np.asarray(R["A1_Full_Signal+NMS"]["spec"], dtype=float) * 100   # full system
A3 = np.asarray(R["A3_NMS_Only"]["spec"],        dtype=float) * 100   # questionnaire only
assert len(A1) == len(A3) == 10, f"expected 10 folds: {len(A1)}, {len(A3)}"

sd1, sd3 = A1.std(ddof=0), A3.std(ddof=0)
red = 100 * (1 - sd1 / sd3)

print("=" * 70)
print("FOLD-LEVEL SPECIFICITY (%)")
print("=" * 70)
print(f"{'Fold':>4}{'A1 (full)':>18}{'A3 (NMS only)':>18}")
for i, (a, b) in enumerate(zip(A1, A3), 1):
    flag = "   <- low A3 fold" if b <= 60 else ""
    print(f"{i:>4}{a:>18.2f}{b:>18.2f}{flag}")
print(f"\n  SD(n)  A1 = {sd1:.2f} pp     A3 = {sd3:.2f} pp")
print(f"  Point estimate of the reduction = {red:.1f}%   (ratio {sd1/sd3:.3f})")

# ----------------------------------------------------------------- tests
lev = stats.levene(A1, A3, center="median")     # Brown-Forsythe
fli = stats.fligner(A1, A3)
bar = stats.bartlett(A1, A3)                    # assumes normality; reference only

print("\n" + "=" * 70)
print("EQUALITY-OF-DISPERSION TESTS  (H0: same specificity spread in both configurations)")
print("=" * 70)
print(f"  Levene (median-centred / Brown-Forsythe)   W = {lev.statistic:.4f}   p = {lev.pvalue:.4f}")
print(f"  Fligner-Killeen                            X = {fli.statistic:.4f}   p = {fli.pvalue:.4f}")
print(f"  Bartlett (assumes normality, reference)    T = {bar.statistic:.4f}   p = {bar.pvalue:.4f}")

# ------------------------------------------------- paired fold bootstrap
# Folds are paired (same participants, same split), so FOLD INDICES are
# resampled jointly to keep the pairing.
rng = np.random.default_rng(BOOT_SEED)
n = len(A1); d = []
for _ in range(N_BOOT):
    idx = rng.integers(0, n, n)
    s1, s3 = A1[idx].std(ddof=0), A3[idx].std(ddof=0)
    if s3 > 0:
        d.append(1 - s1 / s3)
d = np.asarray(d) * 100
lo, hi = np.percentile(d, [2.5, 97.5])
p_pos = float((d > 0).mean())

print("\n" + "=" * 70)
print(f"PAIRED FOLD-LEVEL BOOTSTRAP  ({len(d)}/{N_BOOT} valid, seed {BOOT_SEED})")
print("=" * 70)
print(f"  median reduction     : {np.median(d):>7.1f}%")
print(f"  95% percentile CI    : {lo:>7.1f}%  to  {hi:>7.1f}%")
print(f"  P(reduction > 0)     : {p_pos:>7.2f}")
print(f"  CI contains zero     : {'YES' if lo < 0 < hi else 'NO'}")

# ------------------------------------------------- leave-one-fold-out
print("\n" + "=" * 70)
print("LEAVE-ONE-FOLD-OUT — which fold drives the reduction?")
print("=" * 70)
print(f"{'fold removed':>15}{'SD A1':>9}{'SD A3':>9}{'reduction':>11}")
for i in range(n):
    m = np.ones(n, bool); m[i] = False
    s1, s3 = A1[m].std(ddof=0), A3[m].std(ddof=0)
    r = 100 * (1 - s1 / s3) if s3 > 0 else float("nan")
    mark = "  <-- sign reverses here" if r < 0 else ""
    print(f"{i+1:>15}{s1:>9.2f}{s3:>9.2f}{r:>10.1f}%{mark}")

# ----------------------------------------------------------------- reproduction check
print("\n" + "=" * 70)
print("REPRODUCTION CHECK AGAINST THE REPORTED VALUES")
print("=" * 70)
rows = [("SD A1 (pp)",          sd1,         REPORTED["sd_a1"],         0.01),
        ("SD A3 (pp)",          sd3,         REPORTED["sd_a3"],         0.01),
        ("reduction (%)",       red,         REPORTED["reduction_pct"], 0.6),
        ("Levene p",            lev.pvalue,  REPORTED["levene_p"],      0.005),
        ("Fligner p",           fli.pvalue,  REPORTED["fligner_p"],     0.005),
        ("bootstrap lower (%)", lo,          REPORTED["boot_lo"],       1.5),
        ("bootstrap upper (%)", hi,          REPORTED["boot_hi"],       1.5)]
ok_all = True
for lbl, got, want, tol in rows:
    ok = abs(got - want) <= tol
    ok_all &= ok
    print(f"  {lbl:<22} computed {got:>8.2f}   reported {want:>8.2f}   "
          f"{'MATCH' if ok else 'DIFFERENT'}")
print("\n  " + ("ALL VALUES REPRODUCED." if ok_all else
      "SOME VALUES DIFFER — the bootstrap limits depend on the RNG and may move\n"
      "  by a few points; the SDs and the Levene/Fligner p values should match exactly."))

# ----------------------------------------------------------------- save
out = {
    "source": pkl,
    "spec_per_fold": {"A1_full": A1.tolist(), "A3_nms_only": A3.tolist()},
    "sd_population": {"A1": float(sd1), "A3": float(sd3),
                      "ratio": float(sd1 / sd3), "reduction_pct": float(red)},
    "levene_median_centered": {"W": float(lev.statistic), "p": float(lev.pvalue)},
    "fligner_killeen": {"X": float(fli.statistic), "p": float(fli.pvalue)},
    "bartlett": {"T": float(bar.statistic), "p": float(bar.pvalue)},
    "paired_fold_bootstrap": {"n": int(N_BOOT), "seed": BOOT_SEED,
                              "median_reduction_pct": float(np.median(d)),
                              "ci95_pct": [float(lo), float(hi)],
                              "p_reduction_gt_0": p_pos},
    "matches_manuscript": bool(ok_all),
}
try:
    json.dump(out, open(f"{RUN_DIR}/dispersion_check.json", "w"), indent=2)
    print(f"\nSaved: {RUN_DIR}/dispersion_check.json")
except Exception as e:
    print(f"\n(could not save: {e})")
