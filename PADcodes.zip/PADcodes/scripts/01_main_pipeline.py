# =============================================================================
# 01_main_pipeline.py
# PADS: MiniRocket + RidgeClassifierCV (motion) + logistic regression (NMS
# questionnaire), equal-weight score fusion, participant-level 10-fold
# stratified cross-validation with a Youden threshold chosen on inner 5-fold
# out-of-fold scores of the training participants.
#
# Produces the headline result (A1), the ablation (A2-A4), the classifier
# comparison (B0-B4), pooled out-of-fold metrics, bootstrap intervals,
# prevalence-based predictive values, all figures, results.json and
# raw_predictions.pkl.
#
# Runs as a single Google Colab cell (CPU only) or as a plain Python script.
# RUN_ABLATION = False -> headline only (~1 h on two CPU cores)
# RUN_ABLATION = True  -> everything (~3 h). A checkpoint is written after
# every outer fold; re-running resumes from the last completed fold.
# =============================================================================

RUN_ABLATION      = True      # False = headline only (~1 h), verify 87.91 first
PURGE_CHECKPOINTS = False     # True ONLY for a deliberate clean start
DRIVE_SUBDIR      = 'Parkinson/pads_final_6ch'   # under MyDrive (NEW dir:
                                                 # pads_final is left intact)

# --------------------------------------------------------- mount Drive FIRST
# This must happen before any directory is created, otherwise the folder is
# made on the local disk and then hidden by the mount.
import os, sys, subprocess, json, pickle, gc, time, warnings
from glob import glob
warnings.filterwarnings('ignore')

ON_COLAB = False
try:
    from google.colab import drive
    if not os.path.ismount('/content/drive'):
        drive.mount('/content/drive')
    ON_COLAB = True
except Exception as e:
    print(f"(not on Colab or Drive unavailable: {e})")

if ON_COLAB and os.path.isdir('/content/drive/MyDrive'):
    OUTPUT_DIR = f'/content/drive/MyDrive/{DRIVE_SUBDIR}'
    print(f"Output -> Google Drive: {OUTPUT_DIR}")
    print("Checkpoints survive a runtime reset.")
else:
    OUTPUT_DIR = './pads_final'
    print(f"Output -> local: {OUTPUT_DIR}")
    print("WARNING: on free Colab this is wiped when the runtime is reclaimed.")

# ----------------------------------------------------------------- packages
def _install(pkg):
    try:
        __import__(pkg.split('[')[0].replace('-', '_'))
    except Exception:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', pkg, '-q'],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

for _p in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'sktime', 'matplotlib', 'xgboost', 'tqdm']:
    _install(_p)

import numpy as np
import pandas as pd
try:
    from tqdm import tqdm
except ImportError:
    def tqdm(x, **kw): return x

from scipy.signal import detrend, resample
from scipy.stats import wilcoxon
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.linear_model import RidgeClassifierCV, LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (balanced_accuracy_score, recall_score, f1_score,
                             roc_auc_score, roc_curve, precision_recall_curve,
                             average_precision_score, matthews_corrcoef,
                             brier_score_loss)
from sklearn.calibration import calibration_curve
from sktime.transformations.panel.rocket import MiniRocketMultivariate
from xgboost import XGBClassifier

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ----------------------------------------------------------------- config
RANDOM_STATE = 42
N_CHANNELS   = 6        # 3 accelerometer + 3 gyroscope axes; col 0 (time) dropped
DROP_TIME_COL = True    # set False ONLY to reproduce the old 7-channel run
N_KERNELS    = 8000
N_FOLDS      = 10
SEG_LEN      = 400
DPI          = 600
np.random.seed(RANDOM_STATE)

FIGURE_DIR = f'{OUTPUT_DIR}/figures'
os.makedirs(FIGURE_DIR, exist_ok=True)

_existing = sorted(f for f in os.listdir(OUTPUT_DIR) if f.startswith('ckpt_fold_'))
if PURGE_CHECKPOINTS:
    for _f in _existing:
        os.remove(os.path.join(OUTPUT_DIR, _f))
    if _existing:
        print(f"Purged {len(_existing)} checkpoint(s) — starting clean.")
elif _existing:
    print(f"Found {len(_existing)} checkpoint(s): {', '.join(f[10:-4] for f in _existing)}. "
          f"Completed folds will be reused.")

BENCHMARK = {'BA': 91.16, 'BA_sd': 4.92, 'Se': 92.40, 'Se_sd': 2.64,
             'F1': 94.62, 'F1_sd': 2.21, 'BA_matched': 89.25}
BENCH_SP_DERIVED = 2 * BENCHMARK['BA'] - BENCHMARK['Se']

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.titlesize': 10,
    'axes.labelsize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'legend.fontsize': 8, 'figure.dpi': DPI, 'savefig.dpi': DPI,
    'axes.linewidth': 0.8, 'axes.spines.top': False, 'axes.spines.right': False,
    'lines.linewidth': 1.5, 'grid.linewidth': 0.5, 'grid.alpha': 0.4})
C = {'blue': '#2563EB', 'red': '#DC2626', 'green': '#16A34A', 'amber': '#D97706'}

def save_fig(fig, name):
    p = f'{FIGURE_DIR}/{name}.png'
    fig.savefig(p, dpi=DPI, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"   saved {p}")

def youden_threshold(y_true, scores):
    fpr, tpr, ths = roc_curve(y_true, scores)
    return float(ths[np.argmax(tpr - fpr)])

def wilson_ci(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return 100 * (c - h), 100 * (c + h)

def holm(pvals):
    p = np.asarray(pvals, float); order = np.argsort(p); m = len(p)
    adj = np.empty(m); run = 0.0
    for i, idx in enumerate(order):
        run = max(run, (m - i) * p[idx]); adj[idx] = min(run, 1.0)
    return adj

import sklearn, sktime, xgboost, scipy
RUN_SIGNATURE = {'n_kernels': N_KERNELS, 'seg_len': SEG_LEN, 'n_folds': N_FOLDS, 'seed': RANDOM_STATE,
                 'drop_time_col': DROP_TIME_COL, 'numpy': np.__version__, 'scipy': scipy.__version__,
                 'sklearn': sklearn.__version__, 'sktime': sktime.__version__, 'xgboost': xgboost.__version__}
t_start = time.time()
print("=" * 74)
print("PADS FINAL RUN — headline + ablation, leakage-free, deterministic")
print("=" * 74)

# ================================================================= DATA
def find_file(name):
    for p in [f"/content/{name}", f"/content/drive/MyDrive/{name}",
              f"/content/drive/MyDrive/Parkinson/{name}", f"./{name}"]:
        if os.path.exists(p): return p
    if os.path.exists("/content/drive"):
        r = subprocess.getoutput(f"find /content/drive -name '{name}' -type f 2>/dev/null | head -1")
        if r.strip(): return r.strip()
    return None

def find_data():
    import zipfile as zf
    for d in ["./pads_data_extracted", "/content/pads_data_extracted",
              "/content/pads_extracted", "/content/drive/MyDrive/Parkinson/pads_data_extracted"]:
        if os.path.exists(d) and len(glob(f"{d}/**/*.txt", recursive=True)) > 10:
            return d
    zp = find_file("pads-parkinsons-disease-smartwatch-dataset-1.0.0.zip")
    if zp:
        print("Extracting PADS dataset (to local disk — fast, and re-extractable)...")
        with zf.ZipFile(zp, 'r') as z: z.extractall("./pads_data_extracted")
        return "./pads_data_extracted"
    raise FileNotFoundError("PADS dataset not found. Upload the zip to Colab or Drive.")

data_path = find_data()
print(f"Data: {data_path}")

# -- labels: PD=1, HC=0; the 114 differential-diagnosis participants are excluded
#
# [FIX 2] Labels come from the dataset's own patient_*.json, never from a
# subjects.csv found elsewhere in Drive. Matching is EXACT, not substring:
# `"parkinson" in cond` also matches "Atypical Parkinsonism".
PD_CONDITIONS = {"parkinson", "parkinsons", "parkinson's",
                 "parkinson disease", "parkinsons disease", "parkinson's disease"}
HC_CONDITIONS = {"healthy", "healthy control", "healthy controls", "control"}

def _norm(s):
    return " ".join(str(s).strip().lower().replace("\u2019", "'").split())

def label_of(cond):
    c = _norm(cond)
    if c in PD_CONDITIONS: return 1
    if c in HC_CONDITIONS: return 0
    return -1

from collections import Counter as _Counter
patient_info, _cond_map = {}, _Counter()
_pfiles = sorted(glob(f"{data_path}/**/patient_*.json", recursive=True))
if not _pfiles:
    raise FileNotFoundError("No patient_*.json under data_path — wrong folder?")
for pf in _pfiles:
    try:
        d = json.load(open(pf)); pid = str(d.get('id', ''))
        cond = d.get('condition', '')
        lbl = label_of(cond)
        _cond_map[(_norm(cond), lbl)] += 1
        if lbl >= 0 and pid:
            patient_info[pid] = {'label': lbl, 'age': d.get('age', 60),
                                 'gender': str(d.get('gender', 'unknown'))}
    except Exception: pass

print("   condition -> label mapping (inspect this):")
for (c, l), k in sorted(_cond_map.items(), key=lambda x: -x[1]):
    tag = {1: 'PD ', 0: 'HC ', -1: 'excluded'}[l]
    print(f"      {k:4d}  {tag:9s} {c!r}")
_npd = sum(1 for v in patient_info.values() if v['label'] == 1)
_nhc = sum(1 for v in patient_info.values() if v['label'] == 0)
print(f"   {len(patient_info)} patients (PD={_npd}, HC={_nhc}; DD excluded)")
assert (_npd, _nhc) == (276, 79), (
    f"Expected 276 PD / 79 HC, got {_npd}/{_nhc}. Check the mapping printed "
    f"above before running anything else.")

# -- NMS questionnaire, 30 binary items
nms_data = {}
for qf in sorted(glob(f"{data_path}/**/questionnaire_response_*.json", recursive=True)):
    try:
        q = json.load(open(qf)); pid = str(q.get('subject_id', ''))
        if pid not in patient_info: continue
        ans = [0] * 30
        for it in q.get('item', []):
            try:
                i = int(it.get('link_id', '99')) - 1
                if 0 <= i < 30: ans[i] = 1 if it.get('answer') else 0
            except Exception: pass
        nms_data[pid] = ans
    except Exception: pass
print(f"   {len(nms_data)} NMS questionnaire records")

# -- signals: drop first 50 samples, linear detrend, resample to 400 steps
# [DETERMINISM] sorted() — glob returns filesystem order, which is arbitrary.
# [FIX 3] SHA256SUMS.txt is a .txt with 12,689 rows and no numeric columns.
_SKIP = ("LICENSE", "README", "SHA256SUMS", "RECORDS")
s_files = sorted([f for f in glob(f"{data_path}/**/*.txt", recursive=True)
                  if not any(s in os.path.basename(f).upper() for s in _SKIP)])
print(f"   {len(s_files)} signal files")

patient_segments = {}
_bad_shape = []            # files whose column count is not what we expect
_read_errors = []          # files that could not be parsed at all
for fp in tqdm(s_files, desc="   Loading segments", ncols=70):
    try:
        pid = os.path.basename(fp).split('_')[0]
        if pid not in patient_info: continue
        raw = pd.read_csv(fp, header=None).select_dtypes(include=[np.number]).values
        if len(raw) < 100: continue
        # [FIX 1] Column 0 is time: strictly monotone, r(index) = 1.0000 in every
        # one of the 10,318 files. select_dtypes keeps it because it is numeric.
        # NOTE: recorded rather than raised, because the enclosing `except
        # Exception: continue` would swallow an exception and silently drop the
        # file. Anything collected here is reported loudly after the loop.
        if DROP_TIME_COL:
            if raw.shape[1] != N_CHANNELS + 1:
                _bad_shape.append((fp, raw.shape))
                continue
            raw = raw[:, 1:]
        if len(raw) > 50: raw = raw[50:, :]
        raw = detrend(raw, axis=0)
        if raw.shape[0] > raw.shape[1]: raw = raw.T
        raw = resample(raw, SEG_LEN, axis=1)
        patient_segments.setdefault(pid, []).append(raw)
    except Exception as e:
        _read_errors.append((fp, repr(e))); continue

if _read_errors:
    print(f"   !! {len(_read_errors)} file(s) could not be read, e.g. {_read_errors[:3]}")
if _bad_shape:
    print(f"   !! {len(_bad_shape)} file(s) with an unexpected column count:")
    for fp, sh in _bad_shape[:5]:
        print(f"      {sh}  {os.path.basename(fp)}")
    raise SystemExit("Unexpected channel layout — stop and inspect before running.")

# [DETERMINISM] sorted() — dict order follows insertion order, and StratifiedKFold
# assigns folds by index, so patient order silently changes every fold.
valid_pids = np.array(sorted([p for p in patient_segments if p in patient_info]))
pat_labels = np.array([patient_info[p]['label'] for p in valid_pids])
pat_nms    = np.array([nms_data.get(p, [0] * 30) for p in valid_pids], dtype=np.float32)
max_ch     = max(s.shape[0] for p in valid_pids for s in patient_segments[p])
min_ch     = min(s.shape[0] for p in valid_pids for s in patient_segments[p])
n_seg      = sum(len(patient_segments[p]) for p in valid_pids)
if DROP_TIME_COL:
    assert max_ch == min_ch == N_CHANNELS, (
        f"channels must be exactly {N_CHANNELS} after dropping the time column, "
        f"got min={min_ch} max={max_ch}")

print(f"   {len(valid_pids)} patients | PD={int((pat_labels==1).sum())} "
      f"| HC={int((pat_labels==0).sum())} | segments={n_seg} | channels={max_ch}")
assert (int((pat_labels == 1).sum()), int((pat_labels == 0).sum())) == (276, 79), \
    "patient counts drifted after segment loading"
assert n_seg == 7810, f"expected 7810 segments, got {n_seg}"
print(f"   [checks passed] 276 PD / 79 HC | {n_seg} segments | {max_ch} channels")

def segments_array(pids):
    segs, counts = [], []
    for pid in pids:
        counts.append(len(patient_segments[pid]))
        for seg in patient_segments[pid]:
            padded = np.zeros((max_ch, SEG_LEN), dtype=np.float32)
            padded[:seg.shape[0], :] = seg
            segs.append(padded)
    return np.array(segs, dtype=np.float32), counts

def aggregate_patient(rocket_segs, seg_counts, with_std=True):
    fd = rocket_segs.shape[1]
    X = np.zeros((len(seg_counts), fd * 2 if with_std else fd), dtype=np.float32)
    idx = 0
    for i, cnt in enumerate(seg_counts):
        s = rocket_segs[idx:idx + cnt]
        X[i, :fd] = s.mean(axis=0)
        if with_std: X[i, fd:] = s.std(axis=0)
        idx += cnt
    return X

# ================================================================= MODELS
def ridge_raw():                       # the proposed model — NO scaler
    return RidgeClassifierCV(alphas=np.logspace(-3, 3, 10), class_weight='balanced')
def ridge_scaled():                    # scaling sanity check only
    return Pipeline([('sc', StandardScaler()), ('m', ridge_raw())])
def lr_model():
    return Pipeline([('sc', StandardScaler()),
                     ('m', LogisticRegression(C=1.0, class_weight='balanced',
                                              max_iter=2000, random_state=RANDOM_STATE))])
def rf_model():
    return RandomForestClassifier(n_estimators=300, class_weight='balanced',
                                  n_jobs=-1, random_state=RANDOM_STATE)
from sklearn.base import BaseEstimator, ClassifierMixin

class XGBPerFitRatio(BaseEstimator, ClassifierMixin):
    """XGBoost whose positive-class weight is the control-to-patient ratio of
    the labels passed to *this* fit (outer training fold or inner split), so no
    class information from held-out participants is used."""
    def __init__(self, n_estimators=300, max_depth=4, learning_rate=0.05, random_state=42):
        self.n_estimators = n_estimators; self.max_depth = max_depth
        self.learning_rate = learning_rate; self.random_state = random_state
    def fit(self, X, y):
        y = np.asarray(y); self.classes_ = np.unique(y)
        ratio = float((y == 0).sum() / max((y == 1).sum(), 1))
        self.model_ = XGBClassifier(n_estimators=self.n_estimators, max_depth=self.max_depth,
                                    learning_rate=self.learning_rate, scale_pos_weight=ratio,
                                    eval_metric='logloss', random_state=self.random_state,
                                    verbosity=0, n_jobs=-1).fit(X, y)
        return self
    def predict_proba(self, X): return self.model_.predict_proba(X)
    def predict(self, X): return self.model_.predict(X)

def xgb_model():
    return XGBPerFitRatio(random_state=RANDOM_STATE)
def svm_model():
    # probability=True would run an internal 5-fold Platt calibration on every
    # fit. The decision function is sigmoid-squashed downstream instead, exactly
    # as for Ridge, which is both faster and more consistent across models.
    return Pipeline([('sc', StandardScaler()),
                     ('m', SVC(kernel='rbf', class_weight='balanced',
                               C=1.0, random_state=RANDOM_STATE))])
def nms_model():
    return Pipeline([('sc', StandardScaler()),
                     ('lr', LogisticRegression(C=1.0, class_weight='balanced',
                                               max_iter=1000, random_state=RANDOM_STATE))])

HEAD = 'A1_Full_Signal+NMS'
CONFIGS = [(HEAD, ridge_raw, 'full', True)]
if RUN_ABLATION:
    CONFIGS += [
        ('A2_Signal_Only',        ridge_raw,    'full', False),
        ('A3_NMS_Only',           None,         None,   True),
        ('A4_MeanOnly_No_Std',    ridge_raw,    'mean', True),
        ('B0_Ridge_Scaled',       ridge_scaled, 'full', True),
        ('B1_LogisticRegression', lr_model,     'full', True),
        ('B2_RandomForest',       rf_model,     'full', True),
        ('B3_XGBoost',            xgb_model,    'full', True),
        ('B4_SVM_RBF',            svm_model,    'full', True),
    ]
CONFIG_NAMES = [c[0] for c in CONFIGS]

def scores_from(model_fn, X_tr, y_tr, X_te, inner_cv):
    """Fit; return (train OOF score, test score). Decision functions are sigmoid-squashed."""
    m = model_fn(); m.fit(X_tr, y_tr)
    if hasattr(m, 'decision_function'):
        oof = cross_val_predict(model_fn(), X_tr, y_tr, cv=inner_cv, method='decision_function')
        return 1 / (1 + np.exp(-oof)), 1 / (1 + np.exp(-m.decision_function(X_te)))
    oof = cross_val_predict(model_fn(), X_tr, y_tr, cv=inner_cv, method='predict_proba')[:, 1]
    return oof, m.predict_proba(X_te)[:, 1]

def nms_scores(X_tr, y_tr, X_te, inner_cv):
    """Questionnaire branch — predict_proba explicitly, exactly as in cell 81."""
    m = nms_model(); m.fit(X_tr, y_tr)
    oof = cross_val_predict(nms_model(), X_tr, y_tr, cv=inner_cv, method='predict_proba')[:, 1]
    return oof, m.predict_proba(X_te)[:, 1]

# ================================================================= CV LOOP
outer_cv = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_STATE)
inner_cv = StratifiedKFold(n_splits=5,       shuffle=True, random_state=RANDOM_STATE)

results = {n: {'bal_acc': [], 'sens': [], 'spec': [], 'f1': [], 'auc': []} for n in CONFIG_NAMES}
head_folds, all_true, all_prob, all_pred, all_th = [], [], [], [], []
feat_dim, t_fold = None, []

print("\n" + "=" * 74)
print(f"10-FOLD STRATIFIED CV  |  {len(CONFIGS)} configuration(s) per fold")
print("=" * 74)

for fold, (tr_idx, te_idx) in enumerate(outer_cv.split(valid_pids, pat_labels), 1):
    ck_path = f'{OUTPUT_DIR}/ckpt_fold_{fold}.pkl'
    ck = None
    if os.path.exists(ck_path):
        try: ck = pickle.load(open(ck_path, 'rb'))
        except Exception: ck = None
    if ck and ck.get('signature') != RUN_SIGNATURE:
        print(f"FOLD {fold}: checkpoint ignored (settings or package versions differ)"); ck = None
    if ck and all(n in ck['configs'] for n in CONFIG_NAMES):
        for n in CONFIG_NAMES:
            for k in results[n]:
                results[n][k].append(ck['configs'][n][k])
        head_folds.append(ck['head']); feat_dim = ck.get('feat_dim', feat_dim)
        all_true.extend(ck['head']['y_true']); all_prob.extend(ck['head']['y_prob'])
        all_pred.extend(ck['head']['y_pred']); all_th.append(ck['head']['th'])
        print(f"FOLD {fold}/{N_FOLDS} — from checkpoint | BA={ck['head']['bal_acc']*100:.2f}%")
        continue

    t0 = time.time()
    print(f"\nFOLD {fold}/{N_FOLDS}")
    tr_pids, te_pids = valid_pids[tr_idx], valid_pids[te_idx]
    y_tr, y_te       = pat_labels[tr_idx], pat_labels[te_idx]
    nms_tr, nms_te   = pat_nms[tr_idx],    pat_nms[te_idx]

    # ---- [LEAKAGE POINT 1] MiniRocket fitted on TRAINING segments only,
    #      computed ONCE and reused by every configuration in this fold.
    print(f"   MiniRocket {N_KERNELS//1000}K kernels (training segments only)...")
    tr_segs, tr_counts = segments_array(tr_pids)
    te_segs, te_counts = segments_array(te_pids)
    rocket = MiniRocketMultivariate(num_kernels=N_KERNELS,
                                    random_state=RANDOM_STATE, n_jobs=-1)
    R_tr = rocket.fit_transform(tr_segs)
    R_tr = R_tr.values if hasattr(R_tr, 'values') else np.array(R_tr)
    del tr_segs; gc.collect()
    R_te = rocket.transform(te_segs)
    R_te = R_te.values if hasattr(R_te, 'values') else np.array(R_te)
    del te_segs; gc.collect()
    feat_dim = R_tr.shape[1]

    F = {'full': (aggregate_patient(R_tr, tr_counts, True),
                  aggregate_patient(R_te, te_counts, True))}
    if RUN_ABLATION:
        F['mean'] = (aggregate_patient(R_tr, tr_counts, False),
                     aggregate_patient(R_te, te_counts, False))
    del R_tr, R_te; gc.collect()

    # ---- questionnaire branch, computed once and shared by every config
    nms_oof, nms_te_prob = nms_scores(nms_tr, y_tr, nms_te, inner_cv)

    fold_cfgs, head_pack = {}, None
    for name, model_fn, featset, use_nms in CONFIGS:
        if model_fn is None:
            oof_ens, ens_te = nms_oof, nms_te_prob
        else:
            X_tr, X_te = F[featset]
            sig_oof, sig_te = scores_from(model_fn, X_tr, y_tr, X_te, inner_cv)
            if use_nms:
                oof_ens = (sig_oof + nms_oof) / 2.0        # [LEAKAGE POINT 2]
                ens_te  = (sig_te + nms_te_prob) / 2.0
            else:
                oof_ens, ens_te = sig_oof, sig_te

        th = youden_threshold(y_tr, oof_ens)               # training OOF only
        y_pred = (ens_te >= th).astype(int)
        vals = {'bal_acc': balanced_accuracy_score(y_te, y_pred),
                'sens': recall_score(y_te, y_pred, pos_label=1, zero_division=0),
                'spec': recall_score(y_te, y_pred, pos_label=0, zero_division=0),
                'f1':   f1_score(y_te, y_pred, zero_division=0),
                'auc':  roc_auc_score(y_te, ens_te)}
        fold_cfgs[name] = vals
        for k, v in vals.items():
            results[name][k].append(v)
        if name == HEAD:
            head_pack = dict(vals, fold=fold, th=float(th), n_test=int(len(y_te)),
                             pids=[str(p) for p in te_pids],
                             y_true=[int(v) for v in y_te],
                             y_prob=[float(v) for v in ens_te],
                             y_pred=[int(v) for v in y_pred])
        print(f"      {name:<24} BA={vals['bal_acc']*100:6.2f}%"
              + ("  <- headline" if name == HEAD else ""))

    dt = time.time() - t0; t_fold.append(dt)
    pickle.dump({'configs': fold_cfgs, 'head': head_pack, 'feat_dim': feat_dim,
                 'signature': RUN_SIGNATURE},
                open(ck_path, 'wb'))
    head_folds.append(head_pack)
    all_true.extend(head_pack['y_true']); all_prob.extend(head_pack['y_prob'])
    all_pred.extend(head_pack['y_pred']); all_th.append(head_pack['th'])
    print(f"   fold done in {dt/60:.1f} min  (checkpoint saved)")
    del F; gc.collect()

all_true = np.array(all_true); all_prob = np.array(all_prob)
all_pred = np.array(all_pred); all_th = np.array(all_th)

# ================================================================= HEADLINE
def ms(key):
    # identical arithmetic to `agg` below, so the headline numbers and the
    # A1 row are bit-identical rather than merely equal to two decimals
    v = np.array(results[HEAD][key])
    return np.mean(v) * 100, np.std(v, ddof=0) * 100, np.std(v, ddof=1) * 100

print("\n" + "=" * 74)
print("HEADLINE RESULTS  (= configuration A1)")
print("=" * 74)
print(f"{'Metric':<18}{'Mean':>9}{'SD(n)':>9}{'SD(n-1)':>10}")
print("-" * 46)
summary = {}
for k, lbl in [('bal_acc', 'Balanced Acc'), ('sens', 'Sensitivity'),
               ('spec', 'Specificity'), ('f1', 'F1-Score'), ('auc', 'AUC-ROC')]:
    m, s0, s1 = ms(k); summary[k] = {'mean': m, 'sd_n': s0, 'sd_n1': s1}
    print(f"{lbl:<18}{m:>8.2f}%{s0:>8.2f}%{s1:>9.2f}%")
print(f"\ntau*: mean={all_th.mean():.3f}  SD={all_th.std(ddof=0):.3f}  "
      f"range {all_th.min():.3f}-{all_th.max():.3f}")

tp = int(((all_true == 1) & (all_pred == 1)).sum())
fn = int(((all_true == 1) & (all_pred == 0)).sum())
tn = int(((all_true == 0) & (all_pred == 0)).sum())
fp = int(((all_true == 0) & (all_pred == 1)).sum())
pool_se, pool_sp = tp / (tp + fn), tn / (tn + fp)
pool_ba = 0.5 * (pool_se + pool_sp)
pool_f1 = 2 * tp / (2 * tp + fp + fn)
mcc = matthews_corrcoef(all_true, all_pred)
se_lo, se_hi = wilson_ci(tp, tp + fn)
sp_lo, sp_hi = wilson_ci(tn, tn + fp)
pooled_auc = roc_auc_score(all_true, all_prob)
ap = average_precision_score(all_true, all_prob)
brier = brier_score_loss(all_true, all_prob)

print(f"\nPOOLED  TN={tn}  FP={fp}  FN={fn}  TP={tp}")
print(f"  Se={pool_se*100:.2f}% (Wilson {se_lo:.1f}-{se_hi:.1f})   "
      f"Sp={pool_sp*100:.2f}% (Wilson {sp_lo:.1f}-{sp_hi:.1f})")
print(f"  BA={pool_ba*100:.2f}%  F1={pool_f1*100:.2f}%  MCC={mcc:.4f}")
print(f"  pooled AUC={pooled_auc*100:.2f}%  AvgPrecision={ap*100:.2f}%  Brier={brier:.4f}")

print("\nBootstrap 95% CI (2000 patient-level resamples, percentile, seed 42)...")
np.random.seed(RANDOM_STATE)
boot = []
for _ in range(2000):
    idx = np.random.choice(len(all_true), len(all_true), replace=True)
    if len(np.unique(all_true[idx])) < 2: continue
    boot.append(balanced_accuracy_score(all_true[idx], all_pred[idx]) * 100)
ci_lo, ci_hi = np.percentile(boot, [2.5, 97.5])
print(f"  95% CI: [{ci_lo:.2f}%, {ci_hi:.2f}%]   "
      f"benchmark 91.16 inside: {'YES' if ci_lo <= 91.16 <= ci_hi else 'NO'}")

print("\nScreening performance (pooled Se/Sp; PPV range from the Sp Wilson CI)")
print(f"{'Prev':>6}{'PPV':>9}{'PPV range':>16}{'NPV':>9}{'flag/1000':>11}{'ref/case':>10}")
print("-" * 62)
screening = {}
for pi in (0.003, 0.01, 0.02):
    ppv = lambda sp_: pool_se * pi / (pool_se * pi + (1 - sp_) * (1 - pi)) * 100
    p_hat, p_lo, p_hi = ppv(pool_sp), ppv(sp_lo / 100), ppv(sp_hi / 100)
    npv = pool_sp * (1 - pi) / (pool_sp * (1 - pi) + (1 - pool_se) * pi) * 100
    n_pd = 1000 * pi; tpk, fpk = n_pd * pool_se, (1000 - n_pd) * (1 - pool_sp)
    screening[f"{pi:.3f}"] = {'PPV': p_hat, 'PPV_lo': p_lo, 'PPV_hi': p_hi, 'NPV': npv,
                              'flagged_per_1000': tpk + fpk,
                              'referrals_per_case': (tpk + fpk) / tpk}
    print(f"{pi*100:>5.1f}%{p_hat:>8.1f}%{f'{p_lo:.1f}-{p_hi:.1f}%':>16}"
          f"{npv:>8.2f}%{tpk+fpk:>11.1f}{(tpk+fpk)/tpk:>10.1f}")

ba_m, sp_m = summary['bal_acc']['mean'], summary['spec']['mean']
print(f"\nBenchmark BA 91.16 vs ours {ba_m:.2f}  -> {ba_m-91.16:+.2f} pp")
print(f"Benchmark gender-matched 89.25 vs ours {ba_m:.2f}  -> {ba_m-89.25:+.2f} pp")
print(f"Benchmark derived Sp {BENCH_SP_DERIVED:.2f} vs ours {sp_m:.2f}  "
      f"-> {sp_m-BENCH_SP_DERIVED:+.2f} pp")

print(f"\n{'Fold':>4}{'BA':>9}{'Se':>9}{'Sp':>9}{'F1':>9}{'AUC':>9}{'tau*':>8}")
print("-" * 60)
for h in head_folds:
    print(f"{h['fold']:>4}{h['bal_acc']*100:>8.2f}%{h['sens']*100:>8.2f}%"
          f"{h['spec']*100:>8.2f}%{h['f1']*100:>8.2f}%{h['auc']*100:>8.2f}%{h['th']:>8.3f}")

# ================================================================= ABLATION
agg = {n: {k: (np.mean(v) * 100, np.std(v, ddof=0) * 100) for k, v in d.items()}
       for n, d in results.items()}
stats_out = {}

if RUN_ABLATION:
    folds_ba = {n: np.array(results[n]['bal_acc']) * 100 for n in results}
    ref = folds_ba[HEAD]

    print("\n" + "=" * 74)
    print("ABLATION + CLASSIFIER COMPARISON")
    print("=" * 74)
    print(f"{'Configuration':<26}{'BA':>13}{'Se':>13}{'Sp':>13}{'F1':>13}{'AUC':>13}")
    print("-" * 91)
    for n in CONFIG_NAMES:
        a = agg[n]
        print(f"{n:<26}" + "".join(f"{a[k][0]:>7.2f}±{a[k][1]:<5.2f}"
                                   for k in ['bal_acc', 'sens', 'spec', 'f1', 'auc']))

    def family(names, label):
        Ws, ps = [], []
        for n in names:
            try: W, p = wilcoxon(ref, folds_ba[n])
            except Exception: W, p = float('nan'), 1.0
            Ws.append(float(W)); ps.append(float(p))
        adj = holm(ps)
        print(f"\n{label}  (two-sided Wilcoxon vs A1; Holm within family)")
        print(f"{'Contrast':<26}{'BA':>9}{'delta':>9}{'W':>8}{'p':>9}{'p_Holm':>9}")
        print("-" * 70)
        for n, W, p, a in zip(names, Ws, ps, adj):
            d = agg[n]['bal_acc'][0] - agg[HEAD]['bal_acc'][0]
            print(f"{n:<26}{agg[n]['bal_acc'][0]:>8.2f}%{d:>+9.2f}{W:>8.1f}{p:>9.3f}{a:>9.3f}")
        return {n: {'W': W, 'p': p, 'p_holm': float(a)} for n, W, p, a in zip(names, Ws, ps, adj)}

    stats_out['ablation'] = family(
        ['A2_Signal_Only', 'A3_NMS_Only', 'A4_MeanOnly_No_Std'], "ABLATION")
    stats_out['baselines'] = family(
        ['B1_LogisticRegression', 'B2_RandomForest', 'B3_XGBoost', 'B4_SVM_RBF'],
        "CLASSIFIER COMPARISON")

    try: W0, p0 = wilcoxon(ref, folds_ba['B0_Ridge_Scaled'])
    except Exception: W0, p0 = float('nan'), 1.0
    stats_out['scaling_check'] = {'BA': agg['B0_Ridge_Scaled']['bal_acc'][0],
                                  'W': float(W0), 'p': float(p0)}
    print(f"\nScaling sanity check: Ridge+StandardScaler = "
          f"{agg['B0_Ridge_Scaled']['bal_acc'][0]:.2f}% vs A1 {agg[HEAD]['bal_acc'][0]:.2f}% "
          f"(W={W0:.1f}, p={p0:.3f})")
    print("\nA1 IS the headline result — same computation, not a separate run.")
    print("The manuscript no longer needs two different numbers for the proposed method.")

# ================================================================= FIGURES
print("\nGenerating figures...")
fpr, tpr, _ = roc_curve(all_true, all_prob)
fig, ax = plt.subplots(figsize=(3.5, 3.5))
ax.plot(fpr, tpr, color=C['blue'], lw=2, label=f'Proposed method (AUC = {pooled_auc:.3f})')
ax.plot([0, 1], [0, 1], 'k--', lw=1, label='Random classifier')
ax.plot(1 - pool_sp, pool_se, '*', color=C['blue'], markersize=14,
        label=f'Mean operating point\n(Se = {pool_se*100:.1f}%, Sp = {pool_sp*100:.1f}%)')
ax.set_xlabel('False Positive Rate (1 - Specificity)')
ax.set_ylabel('True Positive Rate (Sensitivity)')
ax.set_title("ROC Curve - Parkinson's Disease Detection")
ax.legend(loc='lower right'); ax.grid(alpha=.3)
save_fig(fig, 'fig1_roc_curve')

cm = np.array([[tn, fp], [fn, tp]], float); cmn = cm / cm.sum(axis=1, keepdims=True)
fig, ax = plt.subplots(figsize=(3.2, 3.0))
im = ax.imshow(cmn, cmap='Blues', vmin=0, vmax=1)
for i in range(2):
    for j in range(2):
        ax.text(j, i, f"{int(cm[i,j])}\n({cmn[i,j]*100:.1f}%)", ha='center', va='center',
                fontsize=11, fontweight='bold', color='white' if cmn[i, j] > .5 else 'black')
ax.set_xticks([0, 1]); ax.set_xticklabels(['Predicted HC', 'Predicted PD'])
ax.set_yticks([0, 1]); ax.set_yticklabels(['True HC', 'True PD'])
ax.set_title('Confusion Matrix (Pooled 10-Fold CV)')
fig.colorbar(im, ax=ax, label='Proportion')
save_fig(fig, 'fig2_confusion_matrix')

names = ['Balanced\nAccuracy', 'Sensitivity', 'Specificity', 'F1-Score', 'AUC-ROC']
keys  = ['bal_acc', 'sens', 'spec', 'f1', 'auc']
ours  = [summary[k]['mean'] for k in keys]; errs = [summary[k]['sd_n'] for k in keys]
bench = [BENCHMARK['BA'], BENCHMARK['Se'], np.nan, BENCHMARK['F1'], np.nan]
bench_e = [BENCHMARK['BA_sd'], BENCHMARK['Se_sd'], np.nan, BENCHMARK['F1_sd'], np.nan]
x = np.arange(5); w = .38
fig, ax = plt.subplots(figsize=(6.0, 3.8))
ax.bar(x - w/2, ours, w, yerr=errs, capsize=3, color=C['blue'], label='Proposed Method')
ax.bar(x + w/2, bench, w, yerr=bench_e, capsize=3, color=C['red'], label='Varghese et al. [C1]')
for i, v in enumerate(ours):
    ax.text(x[i]-w/2, v+errs[i]+1.2, f'{v:.1f}%', ha='center', fontsize=8,
            color=C['blue'], fontweight='bold')
for i, v in enumerate(bench):
    if np.isnan(v):
        ax.text(x[i]+w/2, 66, 'N/R', ha='center', fontsize=7, style='italic', color='gray')
    else:
        ax.text(x[i]+w/2, v+bench_e[i]+1.2, f'{v:.1f}%', ha='center', fontsize=8,
                color=C['red'], fontweight='bold')
ax.set_xticks(x); ax.set_xticklabels(names); ax.set_ylim(65, 105)
ax.set_ylabel('Performance (%)')
ax.set_title('Classification Performance - 10-Fold CV (Mean +/- SD)')
ax.legend(loc='lower right'); ax.grid(axis='y', alpha=.3)
save_fig(fig, 'fig3_metric_comparison')

fb = [h['bal_acc']*100 for h in head_folds]; fs = [h['sens']*100 for h in head_folds]
fsp = [h['spec']*100 for h in head_folds]; folds = np.arange(1, len(fb)+1)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 3.2))
a1.plot(folds, fb, 'o-', color=C['blue'], label='Balanced Accuracy')
a1.axhline(np.mean(fb), ls='--', color=C['blue'], label=f'Mean = {np.mean(fb):.1f}%')
a1.fill_between(folds, np.mean(fb)-np.std(fb), np.mean(fb)+np.std(fb), color=C['blue'], alpha=.12)
a1.axhline(BENCHMARK['BA'], ls=':', color=C['red'], label="Varghese et al. [C1]: 91.16%")
a1.fill_between(folds, BENCHMARK['BA']-BENCHMARK['BA_sd'], BENCHMARK['BA']+BENCHMARK['BA_sd'],
                color=C['red'], alpha=.08)
a1.set_xlabel('Fold'); a1.set_ylabel('Balanced Accuracy (%)')
a1.set_title('Fold-level Balanced Accuracy'); a1.legend(fontsize=7); a1.grid(alpha=.3)
a2.plot(folds, fs, 's-', color=C['green'], label='Sensitivity')
a2.plot(folds, fsp, 'D-', color=C['amber'], label='Specificity')
a2.axhline(np.mean(fs), ls='--', color=C['green'], alpha=.6)
a2.axhline(np.mean(fsp), ls='--', color=C['amber'], alpha=.6)
a2.set_xlabel('Fold'); a2.set_ylabel('Score (%)')
a2.set_title('Sensitivity vs. Specificity per Fold'); a2.legend(fontsize=7); a2.grid(alpha=.3)
fig.suptitle('Cross-Validation Stability Analysis')
save_fig(fig, 'fig4_fold_stability')

fig, ax = plt.subplots(figsize=(4.0, 3.2)); bins = np.linspace(0, 1, 26)
ax.hist(all_prob[all_true == 0], bins=bins, color=C['green'], alpha=.75, label=f'HC (n={tn+fp})')
ax.hist(all_prob[all_true == 1], bins=bins, color='salmon', alpha=.75, label=f'PD (n={tp+fn})')
ax.axvline(all_th.mean(), ls='--', color='black', lw=2,
           label=f'Mean threshold = {all_th.mean():.3f}')
ax.set_xlabel('Ensemble Decision Score'); ax.set_ylabel('Count')
ax.set_title('Ensemble Score Distribution\nby True Class Label')
ax.legend(fontsize=7); ax.grid(alpha=.3)
save_fig(fig, 'fig5_score_distribution')

prec, rec, _ = precision_recall_curve(all_true, all_prob)
base = (all_true == 1).mean()
fig, ax = plt.subplots(figsize=(3.5, 3.5))
ax.plot(rec, prec, color=C['blue'], lw=2, label=f'Proposed method (AP = {ap:.3f})')
ax.axhline(base, ls='--', color='k', lw=1, label=f'No-skill ({base:.3f})')
ax.set_xlabel('Recall (Sensitivity)'); ax.set_ylabel('Precision (PPV)')
ax.set_title('Precision-Recall Curve'); ax.legend(loc='lower left', fontsize=7); ax.grid(alpha=.3)
save_fig(fig, 'fig6_precision_recall')

frac_pos, mean_pred = calibration_curve(all_true, all_prob, n_bins=10, strategy='quantile')
fig, ax = plt.subplots(figsize=(3.5, 3.5))
ax.plot([0, 1], [0, 1], 'k--', lw=1, label='Perfect calibration')
ax.plot(mean_pred, frac_pos, 'o-', color=C['blue'], label=f'Proposed (Brier = {brier:.3f})')
ax.set_xlabel('Mean predicted score'); ax.set_ylabel('Observed frequency of PD')
ax.set_title('Calibration of the Ensemble Score')
ax.legend(loc='upper left', fontsize=7); ax.grid(alpha=.3)
save_fig(fig, 'fig7_calibration')

if RUN_ABLATION:
    order = ['A1_Full_Signal+NMS', 'A2_Signal_Only', 'A3_NMS_Only', 'A4_MeanOnly_No_Std']
    lbls = ['Full System\n(Signal + NMS)\n[A1]', 'Signal Only\n(w/o NMS)\n[A2]',
            'NMS Only\n(w/o Signal)\n[A3]', 'Mean Only\n(No Std)\n[A4]']
    xx = np.arange(4); ww = .26
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    for j, (k, lab, col) in enumerate([('bal_acc', 'Balanced Accuracy', '#1E3A8A'),
                                       ('sens', 'Sensitivity', '#2563EB'),
                                       ('spec', 'Specificity', '#93C5FD')]):
        vals = [agg[n][k][0] for n in order]; es = [agg[n][k][1] for n in order]
        ax.bar(xx + (j-1)*ww, vals, ww, yerr=es, capsize=3, color=col, label=lab)
    ax.set_xticks(xx); ax.set_xticklabels(lbls, fontsize=8)
    ax.set_ylabel('Performance (%)'); ax.set_ylim(60, 102)
    ax.axhline(agg[HEAD]['bal_acc'][0], ls='--', color=C['blue'], alpha=.5)
    ax.set_title('Ablation Study - Component Contributions (10-Fold CV, Mean +/- SD)')
    ax.legend(loc='lower right'); ax.grid(axis='y', alpha=.3)
    save_fig(fig, 'fig8_ablation')

# ================================================================= EXPORT
runtime = time.time() - t_start
out = {
    'run': 'pads_final_6ch',
    'ablation_included': RUN_ABLATION,
    'protocol': 'per-fold MiniRocket fit; Ridge without StandardScaler; '
                'headline result IS configuration A1 (same computation); '
                'SVM uses decision_function + sigmoid (no Platt calibration)',
    'n_patients': int(len(valid_pids)), 'n_pd': int((pat_labels == 1).sum()),
    'n_hc': int((pat_labels == 0).sum()), 'n_segments': int(n_seg),
    'n_channels': int(max_ch), 'time_column_dropped': bool(DROP_TIME_COL),
    'minirocket_kernels': N_KERNELS,
    'minirocket_features': int(feat_dim or 0), 'patient_feature_dim': int((feat_dim or 0) * 2),
    'headline': {
        'summary': summary,
        'fold_metrics': {k: [float(v)*100 for v in results[HEAD][k]] for k in results[HEAD]},
        'thresholds': [float(t) for t in all_th],
        'threshold_mean': float(all_th.mean()), 'threshold_sd': float(all_th.std(ddof=0)),
        'threshold_min': float(all_th.min()), 'threshold_max': float(all_th.max()),
        'pooled': {'TN': tn, 'FP': fp, 'FN': fn, 'TP': tp, 'Se': pool_se*100,
                   'Sp': pool_sp*100, 'BA': pool_ba*100, 'F1': pool_f1*100,
                   'MCC': float(mcc), 'AUC': pooled_auc*100,
                   'average_precision': ap*100, 'brier': float(brier),
                   'Se_wilson': [se_lo, se_hi], 'Sp_wilson': [sp_lo, sp_hi]},
        'bootstrap_ci': [float(ci_lo), float(ci_hi)], 'bootstrap_n': 2000,
        'bootstrap_unit': 'patient-level, pooled OOF predictions, percentile',
        'screening': screening,
    },
    'configurations': {n: {k: {'mean': v[0], 'sd_n': v[1]} for k, v in agg[n].items()}
                       for n in agg},
    'fold_balanced_accuracy': {n: [float(v)*100 for v in results[n]['bal_acc']] for n in results},
    'stats': stats_out,
    'benchmark': {**BENCHMARK, 'Sp_derived': BENCH_SP_DERIVED},
    'runtime_seconds_total': runtime,
    'runtime_seconds_per_fold_mean': float(np.mean(t_fold)) if t_fold else None,
}
json.dump(out, open(f'{OUTPUT_DIR}/results.json', 'w'), indent=2)
all_pids = np.array([p for h in head_folds for p in h.get('pids', [])])
pickle.dump({'head_folds': head_folds, 'all_pids': all_pids, 'all_true': all_true,
             'all_prob': all_prob, 'all_pred': all_pred, 'results': results},
            open(f'{OUTPUT_DIR}/raw_predictions.pkl', 'wb'))

print(f"\nTotal runtime: {runtime/60:.1f} min"
      + (f" ({np.mean(t_fold)/60:.1f} min/fold)" if t_fold else " (all folds from checkpoint)"))
print("=" * 74)
print(f"DONE.   Results:  {OUTPUT_DIR}/results.json")
print(f"Figures:          {FIGURE_DIR}/")
print("=" * 74)

try:
    import zipfile
    with zipfile.ZipFile(f'{OUTPUT_DIR}/figures.zip', 'w') as z:
        for f in sorted(os.listdir(FIGURE_DIR)):
            if f.endswith('.png'): z.write(os.path.join(FIGURE_DIR, f), f)
    print(f"Figures zipped:   {OUTPUT_DIR}/figures.zip")
except Exception as e:
    print(f"(zip skipped: {e})")