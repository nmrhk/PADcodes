# =============================================================================
# 02_dispersion_tests.py
# Is the lower cross-fold SD of specificity with the motion branch (A1 vs A3)
# more than sampling variability? Median-centred Levene test, Fligner-Killeen
# test, paired fold-level bootstrap of 1 - SD(A1)/SD(A3) (10,000 resamples)
# and leave-one-fold-out recomputation. Reads raw_predictions.pkl from
# 01_main_pipeline.py; no model is refitted (~10 s).
# Output: <RUN_DIR>/dispersion_check.json
# =============================================================================
import os, json, pickle, numpy as np
from scipy import stats

RUN_DIR   = "/content/drive/MyDrive/Parkinson/pads_final_6ch"
N_BOOT    = 10000
BOOT_SEED = 42

# makalede yazan degerler (dogrulama hedefi)
CLAIMED = {"levene_p": 1.00, "fligner_p": 0.46,
           "boot_lo": -83.7, "boot_hi": 54.8,
           "sd_a1": 9.76, "sd_a3": 14.84, "reduction_pct": 34}

# ----------------------------------------------------------------- veri
if not os.path.exists("/content/drive/MyDrive"):
    try:
        from google.colab import drive; drive.mount("/content/drive")
    except Exception as e:
        print(f"(Drive mount yok: {e})")

pkl = f"{RUN_DIR}/raw_predictions.pkl"
assert os.path.exists(pkl), f"Bulunamadi: {pkl}"
R = pickle.load(open(pkl, "rb"))["results"]

A1 = np.asarray(R["A1_Full_Signal+NMS"]["spec"], dtype=float) * 100   # tam sistem
A3 = np.asarray(R["A3_NMS_Only"]["spec"],        dtype=float) * 100   # sadece anket
assert len(A1) == len(A3) == 10, f"10 kat bekleniyordu: {len(A1)}, {len(A3)}"

sd1, sd3 = A1.std(ddof=0), A3.std(ddof=0)
red = 100 * (1 - sd1 / sd3)

print("=" * 70)
print("KAT DUZEYINDE OZGULLUK (%)")
print("=" * 70)
print(f"{'Kat':>4}{'A1 (tam sistem)':>18}{'A3 (anket only)':>18}")
for i, (a, b) in enumerate(zip(A1, A3), 1):
    flag = "   <- A3'un dusuk kati" if b <= 60 else ""
    print(f"{i:>4}{a:>18.2f}{b:>18.2f}{flag}")
print(f"\n  SD(n)  A1 = {sd1:.2f} pp     A3 = {sd3:.2f} pp")
print(f"  Nokta tahmini azalma = {red:.1f}%   (oran {sd1/sd3:.3f})")

# ----------------------------------------------------------------- testler
lev = stats.levene(A1, A3, center="median")     # Brown-Forsythe
fli = stats.fligner(A1, A3)
bar = stats.bartlett(A1, A3)                    # normallik varsayar; referans icin

print("\n" + "=" * 70)
print("DAGILIM ESITLIGI TESTLERI  (H0: iki konfigurasyonun ozgulluk sacilimi ayni)")
print("=" * 70)
print(f"  Levene (median-merkezli / Brown-Forsythe)  W = {lev.statistic:.4f}   p = {lev.pvalue:.4f}")
print(f"  Fligner-Killeen                            X = {fli.statistic:.4f}   p = {fli.pvalue:.4f}")
print(f"  Bartlett (normallik varsayar, referans)    T = {bar.statistic:.4f}   p = {bar.pvalue:.4f}")

# ------------------------------------------------- eslestirilmis kat bootstrap
# Katlar eslesiktir (ayni hastalar, ayni bolme), bu yuzden KAT INDEKSLERI
# birlikte yeniden orneklenir; boylece eslesme korunur.
rng = np.random.default_rng(BOOT_SEED)
n = len(A1); d = []
for _ in range(N_BOOT):
    idx = rng.integers(0, n, n)
    s1, s3 = A1[idx].std(ddof=0), A3[idx].std(ddof=0)
    if s3 > 0:
        d.append(1 - s1 / s3)
d = np.asarray(d) * 100
lo, hi = np.percentile(d, [2.5, 97.5])
p_pos = float((d > 0).mean())

print("\n" + "=" * 70)
print(f"ESLESTIRILMIS KAT DUZEYI BOOTSTRAP  ({len(d)}/{N_BOOT} gecerli, seed {BOOT_SEED})")
print("=" * 70)
print(f"  Azalma medyani     : {np.median(d):>7.1f}%")
print(f"  %95 persentil GA   : {lo:>7.1f}%  ile  {hi:>7.1f}%")
print(f"  P(azalma > 0)      : {p_pos:>7.2f}")
print(f"  GA sifiri iceriyor : {'EVET' if lo < 0 < hi else 'HAYIR'}")

# ------------------------------------------------- tek kat cikarma (duyarlilik)
print("\n" + "=" * 70)
print("TEK KAT CIKARMA — azalma hangi kata bagli?")
print("=" * 70)
print(f"{'cikarilan kat':>15}{'SD A1':>9}{'SD A3':>9}{'azalma':>10}")
for i in range(n):
    m = np.ones(n, bool); m[i] = False
    s1, s3 = A1[m].std(ddof=0), A3[m].std(ddof=0)
    r = 100 * (1 - s1 / s3) if s3 > 0 else float("nan")
    mark = "  <-- burada isaret tersine donuyor" if r < 0 else ""
    print(f"{i+1:>15}{s1:>9.2f}{s3:>9.2f}{r:>9.1f}%{mark}")

# ----------------------------------------------------------------- karsilastirma
print("\n" + "=" * 70)
print("MAKALEDEKI DEGERLERLE KARSILASTIRMA")
print("=" * 70)
rows = [("SD A1 (pp)",        sd1,      CLAIMED["sd_a1"],         0.01),
        ("SD A3 (pp)",        sd3,      CLAIMED["sd_a3"],         0.01),
        ("azalma (%)",        red,      CLAIMED["reduction_pct"], 0.6),
        ("Levene p",          lev.pvalue,  CLAIMED["levene_p"],   0.005),
        ("Fligner p",         fli.pvalue,  CLAIMED["fligner_p"],  0.005),
        ("bootstrap alt (%)", lo,       CLAIMED["boot_lo"],       1.5),
        ("bootstrap ust (%)", hi,       CLAIMED["boot_hi"],       1.5)]
ok_all = True
for lbl, got, want, tol in rows:
    ok = abs(got - want) <= tol
    ok_all &= ok
    print(f"  {lbl:<20} hesaplanan {got:>8.2f}   makale {want:>8.2f}   "
          f"{'ESLESTI' if ok else 'FARKLI'}")
print("\n  " + ("TUM DEGERLER DOGRULANDI." if ok_all else
      "BAZI DEGERLER FARKLI — bootstrap alt/ust sinirlari RNG'ye bagli olarak\n"
      "  birkac puan oynayabilir; Levene/Fligner ve SD'ler tam eslesmelidir."))

print("\nSONUC (metne giren yorum):")
print("  Ozgulluk sacilimindaki fark, on kat ve kat basina yedi-sekiz kontrol ile")
print("  ornekleme degiskenliginden ayirt edilemiyor. Nokta tahmini azalma")
print(f"  {red:.0f}% olsa da guven araligi sifiri genis bicimde iceriyor.")

# ----------------------------------------------------------------- kaydet
out = {
    "source": pkl,
    "spec_per_fold": {"A1_full": A1.tolist(), "A3_nms_only": A3.tolist()},
    "sd_population": {"A1": float(sd1), "A3": float(sd3),
                      "ratio": float(sd1 / sd3), "reduction_pct": float(red)},
    "levene_median_centered": {"W": float(lev.statistic), "p": float(lev.pvalue)},
    "fligner_killeen": {"X": float(fli.statistic), "p": float(fli.pvalue)},
    "bartlett": {"T": float(bar.statistic), "p": float(bar.pvalue)},
    "paired_fold_bootstrap": {"n": int(N_BOOT), "seed": BOOT_SEED,
                              "median_reduction_pct": float(np.median(d)),
                              "ci95_pct": [float(lo), float(hi)],
                              "p_reduction_gt_0": p_pos},
    "matches_manuscript": bool(ok_all),
}
try:
    json.dump(out, open(f"{RUN_DIR}/dispersion_check.json", "w"), indent=2)
    print(f"\nKaydedildi: {RUN_DIR}/dispersion_check.json")
except Exception as e:
    print(f"\n(kaydedilemedi: {e})")