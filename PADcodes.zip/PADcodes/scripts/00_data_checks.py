# =============================================================================
# 00_data_checks.py
# Input checks on the PADS release before any modelling (seconds):
#   * 276 PD and 79 healthy-control participants (exact condition labels)
#   * 22 movement recordings per participant (11 tasks x 2 wrists)
#   * a questionnaire for every participant, item ids exactly 1..30 without
#     duplicates, and a boolean answer for every item
#   * patient-record fields (e.g. whether medication or disease stage is present)
# =============================================================================
import os, re, json, zipfile
from collections import Counter

ZIP = '/content/drive/MyDrive/Parkinson/pads-parkinsons-disease-smartwatch-dataset-1.0.0.zip'
try:
    from google.colab import drive
    if not os.path.ismount('/content/drive'):
        drive.mount('/content/drive')
except Exception as e:
    print(f"(not on Colab: {e})")

PD = {"parkinson", "parkinsons", "parkinson's", "parkinson disease", "parkinsons disease", "parkinson's disease"}
HC = {"healthy", "healthy control", "healthy controls", "control"}
norm = lambda s: " ".join(str(s).strip().lower().replace("\u2019", "'").split())

z = zipfile.ZipFile(ZIP); names = z.namelist()
patients = {}
for n in names:
    if re.search(r'patient_[^/]*\.json$', n):
        d = json.loads(z.read(n)); c = norm(d.get('condition', ''))
        if c in PD or c in HC:
            patients[str(d['id'])] = {'label': int(c in PD), 'keys': sorted(d)}
print(f"participants: {len(patients)} | PD {sum(v['label'] for v in patients.values())} | "
      f"HC {sum(1 - v['label'] for v in patients.values())}")
print("patient-record fields:", sorted({k for v in patients.values() for k in v['keys']}))

skip = ("LICENSE", "README", "SHA256SUMS", "RECORDS")
rec = Counter(os.path.basename(n).split('_')[0] for n in names
              if n.endswith('.txt') and not any(s in os.path.basename(n).upper() for s in skip))
bad_rec = {p: rec.get(p, 0) for p in patients if rec.get(p, 0) != 22}
print(f"participants without exactly 22 recordings: {len(bad_rec)} {list(bad_rec.items())[:5]}")

q = {}
for n in names:
    if re.search(r'questionnaire_response_[^/]*\.json$', n):
        d = json.loads(z.read(n)); q[str(d.get('subject_id'))] = d.get('item', [])
problems = []
for p in patients:
    items = q.get(p)
    if items is None: problems.append((p, 'no questionnaire')); continue
    try: ids = sorted(int(it.get('link_id')) for it in items)
    except Exception: problems.append((p, 'non-numeric item id')); continue
    if ids != list(range(1, 31)): problems.append((p, f'ids not 1..30 (n={len(ids)}, unique={len(set(ids))})'))
    if any(not isinstance(it.get('answer'), bool) for it in items): problems.append((p, 'missing/non-boolean answer'))
print(f"questionnaire problems: {len(problems)} {problems[:5]}")
