# =============================================================================
# 06_xgboost_perfit_update.py
# Re-runs only the XGBoost comparator (Table 7) with the positive-class weight
# computed from the labels of each fit (outer training fold and inner splits),
# fused with the same questionnaire branch and evaluated with the same folds and
# threshold rule as 01_main_pipeline.py. The other comparators and A1 are read
# from the saved raw_predictions.pkl, and the Holm adjustment over the four
# alternative classifiers is recomputed. The script also checks the input data:
# 22 recordings per participant and a complete, non-duplicated 30-item
# questionnaire with boolean answers for every participant.
# Runtime ~1 h on two CPU cores; a checkpoint is written after every fold.
# Output: <OUTPUT_DIR>/xgb_perfit_update.json
# =============================================================================

RUN_ABLATION      = False     # False = headline only (~1 h), verify 87.91 first
PURGE_CHECKPOINTS = False     # True ONLY for a deliberate clean start
DRIVE_SUBDIR      = 'Parkinson/pads_xgb_perfit'   # under MyDrive (NEW dir:
                                                 # pads_final is left intact)

# --------------------------------------------------------- mount Drive FIRST
# This must happen before any directory is created, otherwise the folder is
# made on the local disk and then hidden by the mount.
import os, sys, subprocess, json, pickle, gc, time, warnings
from glob import glob
warnings.filterwarnings('ignore')

ON_COLAB = False
try:
    from google.colab import drive
    if not os.path.ismount('/content/drive'):
        drive.mount('/content/drive')
    ON_COLAB = True
except Exception as e:
    print(f"(not on Colab or Drive unavailable: {e})")

if ON_COLAB and os.path.isdir('/content/drive/MyDrive'):
    OUTPUT_DIR = f'/content/drive/MyDrive/{DRIVE_SUBDIR}'
    print(f"Output -> Google Drive: {OUTPUT_DIR}")
    print("Checkpoints survive a runtime reset.")
else:
    OUTPUT_DIR = './pads_final'
    print(f"Output -> local: {OUTPUT_DIR}")
    print("WARNING: on free Colab this is wiped when the runtime is reclaimed.")

# ----------------------------------------------------------------- packages
def _install(pkg):
    try:
        __import__(pkg.split('[')[0].replace('-', '_'))
    except Exception:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', pkg, '-q'],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

for _p in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'sktime', 'matplotlib', 'xgboost', 'tqdm']:
    _install(_p)

import numpy as np
import pandas as pd
try:
    from tqdm import tqdm
except ImportError:
    def tqdm(x, **kw): return x

from scipy.signal import detrend, resample
from scipy.stats import wilcoxon
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.linear_model import RidgeClassifierCV, LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (balanced_accuracy_score, recall_score, f1_score,
                             roc_auc_score, roc_curve, precision_recall_curve,
                             average_precision_score, matthews_corrcoef,
                             brier_score_loss)
from sklearn.calibration import calibration_curve
from sktime.transformations.panel.rocket import MiniRocketMultivariate
from xgboost import XGBClassifier

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ----------------------------------------------------------------- config
RANDOM_STATE = 42
N_CHANNELS   = 6        # 3 accelerometer + 3 gyroscope axes; col 0 (time) dropped
DROP_TIME_COL = True    # set False ONLY to reproduce the old 7-channel run
N_KERNELS    = 8000
N_FOLDS      = 10
SEG_LEN      = 400
DPI          = 600
np.random.seed(RANDOM_STATE)

FIGURE_DIR = f'{OUTPUT_DIR}/figures'
os.makedirs(FIGURE_DIR, exist_ok=True)

_existing = sorted(f for f in os.listdir(OUTPUT_DIR) if f.startswith('ckpt_fold_'))
if PURGE_CHECKPOINTS:
    for _f in _existing:
        os.remove(os.path.join(OUTPUT_DIR, _f))
    if _existing:
        print(f"Purged {len(_existing)} checkpoint(s) — starting clean.")
elif _existing:
    print(f"Found {len(_existing)} checkpoint(s): {', '.join(f[10:-4] for f in _existing)}. "
          f"Completed folds will be reused.")

BENCHMARK = {'BA': 91.16, 'BA_sd': 4.92, 'Se': 92.40, 'Se_sd': 2.64,
             'F1': 94.62, 'F1_sd': 2.21, 'BA_matched': 89.25}
BENCH_SP_DERIVED = 2 * BENCHMARK['BA'] - BENCHMARK['Se']

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.titlesize': 10,
    'axes.labelsize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'legend.fontsize': 8, 'figure.dpi': DPI, 'savefig.dpi': DPI,
    'axes.linewidth': 0.8, 'axes.spines.top': False, 'axes.spines.right': False,
    'lines.linewidth': 1.5, 'grid.linewidth': 0.5, 'grid.alpha': 0.4})
C = {'blue': '#2563EB', 'red': '#DC2626', 'green': '#16A34A', 'amber': '#D97706'}

def save_fig(fig, name):
    p = f'{FIGURE_DIR}/{name}.png'
    fig.savefig(p, dpi=DPI, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"   saved {p}")

def youden_threshold(y_true, scores):
    fpr, tpr, ths = roc_curve(y_true, scores)
    return float(ths[np.argmax(tpr - fpr)])

def wilson_ci(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return 100 * (c - h), 100 * (c + h)

def holm(pvals):
    p = np.asarray(pvals, float); order = np.argsort(p); m = len(p)
    adj = np.empty(m); run = 0.0
    for i, idx in enumerate(order):
        run = max(run, (m - i) * p[idx]); adj[idx] = min(run, 1.0)
    return adj

import sklearn, sktime, xgboost, scipy
RUN_SIGNATURE = {'n_kernels': N_KERNELS, 'seg_len': SEG_LEN, 'n_folds': N_FOLDS, 'seed': RANDOM_STATE,
                 'drop_time_col': DROP_TIME_COL, 'numpy': np.__version__, 'scipy': scipy.__version__,
                 'sklearn': sklearn.__version__, 'sktime': sktime.__version__, 'xgboost': xgboost.__version__}
t_start = time.time()
print("=" * 74)
print("PADS FINAL RUN — headline + ablation, leakage-free, deterministic")
print("=" * 74)

# ================================================================= DATA
def find_file(name):
    for p in [f"/content/{name}", f"/content/drive/MyDrive/{name}",
              f"/content/drive/MyDrive/Parkinson/{name}", f"./{name}"]:
        if os.path.exists(p): return p
    if os.path.exists("/content/drive"):
        r = subprocess.getoutput(f"find /content/drive -name '{name}' -type f 2>/dev/null | head -1")
        if r.strip(): return r.strip()
    return None

def find_data():
    import zipfile as zf
    for d in ["./pads_data_extracted", "/content/pads_data_extracted",
              "/content/pads_extracted", "/content/drive/MyDrive/Parkinson/pads_data_extracted"]:
        if os.path.exists(d) and len(glob(f"{d}/**/*.txt", recursive=True)) > 10:
            return d
    zp = find_file("pads-parkinsons-disease-smartwatch-dataset-1.0.0.zip")
    if zp:
        print("Extracting PADS dataset (to local disk — fast, and re-extractable)...")
        with zf.ZipFile(zp, 'r') as z: z.extractall("./pads_data_extracted")
        return "./pads_data_extracted"
    raise FileNotFoundError("PADS dataset not found. Upload the zip to Colab or Drive.")

data_path = find_data()
print(f"Data: {data_path}")

# -- labels: PD=1, HC=0; the 114 differential-diagnosis participants are excluded
#
# [FIX 2] Labels come from the dataset's own patient_*.json, never from a
# subjects.csv found elsewhere in Drive. Matching is EXACT, not substring:
# `"parkinson" in cond` also matches "Atypical Parkinsonism".
PD_CONDITIONS = {"parkinson", "parkinsons", "parkinson's",
                 "parkinson disease", "parkinsons disease", "parkinson's disease"}
HC_CONDITIONS = {"healthy", "healthy control", "healthy controls", "control"}

def _norm(s):
    return " ".join(str(s).strip().lower().replace("\u2019", "'").split())

def label_of(cond):
    c = _norm(cond)
    if c in PD_CONDITIONS: return 1
    if c in HC_CONDITIONS: return 0
    return -1

from collections import Counter as _Counter
patient_info, _cond_map = {}, _Counter()
_pfiles = sorted(glob(f"{data_path}/**/patient_*.json", recursive=True))
if not _pfiles:
    raise FileNotFoundError("No patient_*.json under data_path — wrong folder?")
for pf in _pfiles:
    try:
        d = json.load(open(pf)); pid = str(d.get('id', ''))
        cond = d.get('condition', '')
        lbl = label_of(cond)
        _cond_map[(_norm(cond), lbl)] += 1
        if lbl >= 0 and pid:
            patient_info[pid] = {'label': lbl, 'age': d.get('age', 60),
                                 'gender': str(d.get('gender', 'unknown'))}
    except Exception: pass

print("   condition -> label mapping (inspect this):")
for (c, l), k in sorted(_cond_map.items(), key=lambda x: -x[1]):
    tag = {1: 'PD ', 0: 'HC ', -1: 'excluded'}[l]
    print(f"      {k:4d}  {tag:9s} {c!r}")
_npd = sum(1 for v in patient_info.values() if v['label'] == 1)
_nhc = sum(1 for v in patient_info.values() if v['label'] == 0)
print(f"   {len(patient_info)} patients (PD={_npd}, HC={_nhc}; DD excluded)")
assert (_npd, _nhc) == (276, 79), (
    f"Expected 276 PD / 79 HC, got {_npd}/{_nhc}. Check the mapping printed "
    f"above before running anything else.")

# -- NMS questionnaire, 30 binary items
nms_data = {}
for qf in sorted(glob(f"{data_path}/**/questionnaire_response_*.json", recursive=True)):
    try:
        q = json.load(open(qf)); pid = str(q.get('subject_id', ''))
        if pid not in patient_info: continue
        ans = [0] * 30
        for it in q.get('item', []):
            try:
                i = int(it.get('link_id', '99')) - 1
                if 0 <= i < 30: ans[i] = 1 if it.get('answer') else 0
            except Exception: pass
        nms_data[pid] = ans
    except Exception: pass
print(f"   {len(nms_data)} NMS questionnaire records")

# -- signals: drop first 50 samples, linear detrend, resample to 400 steps
# [DETERMINISM] sorted() — glob returns filesystem order, which is arbitrary.
# [FIX 3] SHA256SUMS.txt is a .txt with 12,689 rows and no numeric columns.
_SKIP = ("LICENSE", "README", "SHA256SUMS", "RECORDS")
s_files = sorted([f for f in glob(f"{data_path}/**/*.txt", recursive=True)
                  if not any(s in os.path.basename(f).upper() for s in _SKIP)])
print(f"   {len(s_files)} signal files")

patient_segments = {}
_bad_shape = []            # files whose column count is not what we expect
_read_errors = []          # files that could not be parsed at all
for fp in tqdm(s_files, desc="   Loading segments", ncols=70):
    try:
        pid = os.path.basename(fp).split('_')[0]
        if pid not in patient_info: continue
        raw = pd.read_csv(fp, header=None).select_dtypes(include=[np.number]).values
        if len(raw) < 100: continue
        # [FIX 1] Column 0 is time: strictly monotone, r(index) = 1.0000 in every
        # one of the 10,318 files. select_dtypes keeps it because it is numeric.
        # NOTE: recorded rather than raised, because the enclosing `except
        # Exception: continue` would swallow an exception and silently drop the
        # file. Anything collected here is reported loudly after the loop.
        if DROP_TIME_COL:
            if raw.shape[1] != N_CHANNELS + 1:
                _bad_shape.append((fp, raw.shape))
                continue
            raw = raw[:, 1:]
        if len(raw) > 50: raw = raw[50:, :]
        raw = detrend(raw, axis=0)
        if raw.shape[0] > raw.shape[1]: raw = raw.T
        raw = resample(raw, SEG_LEN, axis=1)
        patient_segments.setdefault(pid, []).append(raw)
    except Exception as e:
        _read_errors.append((fp, repr(e))); continue

if _read_errors:
    print(f"   !! {len(_read_errors)} file(s) could not be read, e.g. {_read_errors[:3]}")
if _bad_shape:
    print(f"   !! {len(_bad_shape)} file(s) with an unexpected column count:")
    for fp, sh in _bad_shape[:5]:
        print(f"      {sh}  {os.path.basename(fp)}")
    raise SystemExit("Unexpected channel layout — stop and inspect before running.")

# [DETERMINISM] sorted() — dict order follows insertion order, and StratifiedKFold
# assigns folds by index, so patient order silently changes every fold.
valid_pids = np.array(sorted([p for p in patient_segments if p in patient_info]))
pat_labels = np.array([patient_info[p]['label'] for p in valid_pids])
pat_nms    = np.array([nms_data.get(p, [0] * 30) for p in valid_pids], dtype=np.float32)
max_ch     = max(s.shape[0] for p in valid_pids for s in patient_segments[p])
min_ch     = min(s.shape[0] for p in valid_pids for s in patient_segments[p])
n_seg      = sum(len(patient_segments[p]) for p in valid_pids)
if DROP_TIME_COL:
    assert max_ch == min_ch == N_CHANNELS, (
        f"channels must be exactly {N_CHANNELS} after dropping the time column, "
        f"got min={min_ch} max={max_ch}")

print(f"   {len(valid_pids)} patients | PD={int((pat_labels==1).sum())} "
      f"| HC={int((pat_labels==0).sum())} | segments={n_seg} | channels={max_ch}")
assert (int((pat_labels == 1).sum()), int((pat_labels == 0).sum())) == (276, 79), \
    "patient counts drifted after segment loading"
assert n_seg == 7810, f"expected 7810 segments, got {n_seg}"
print(f"   [checks passed] 276 PD / 79 HC | {n_seg} segments | {max_ch} channels")

def segments_array(pids):
    segs, counts = [], []
    for pid in pids:
        counts.append(len(patient_segments[pid]))
        for seg in patient_segments[pid]:
            padded = np.zeros((max_ch, SEG_LEN), dtype=np.float32)
            padded[:seg.shape[0], :] = seg
            segs.append(padded)
    return np.array(segs, dtype=np.float32), counts

def aggregate_patient(rocket_segs, seg_counts, with_std=True):
    fd = rocket_segs.shape[1]
    X = np.zeros((len(seg_counts), fd * 2 if with_std else fd), dtype=np.float32)
    idx = 0
    for i, cnt in enumerate(seg_counts):
        s = rocket_segs[idx:idx + cnt]
        X[i, :fd] = s.mean(axis=0)
        if with_std: X[i, fd:] = s.std(axis=0)
        idx += cnt
    return X

# ================================================================= MODELS
def ridge_raw():                       # the proposed model — NO scaler
    return RidgeClassifierCV(alphas=np.logspace(-3, 3, 10), class_weight='balanced')
def ridge_scaled():                    # scaling sanity check only
    return Pipeline([('sc', StandardScaler()), ('m', ridge_raw())])
def lr_model():
    return Pipeline([('sc', StandardScaler()),
                     ('m', LogisticRegression(C=1.0, class_weight='balanced',
                                              max_iter=2000, random_state=RANDOM_STATE))])
def rf_model():
    return RandomForestClassifier(n_estimators=300, class_weight='balanced',
                                  n_jobs=-1, random_state=RANDOM_STATE)
from sklearn.base import BaseEstimator, ClassifierMixin

class XGBPerFitRatio(BaseEstimator, ClassifierMixin):
    """XGBoost whose positive-class weight is the control-to-patient ratio of
    the labels passed to *this* fit (outer training fold or inner split), so no
    class information from held-out participants is used."""
    def __init__(self, n_estimators=300, max_depth=4, learning_rate=0.05, random_state=42):
        self.n_estimators = n_estimators; self.max_depth = max_depth
        self.learning_rate = learning_rate; self.random_state = random_state
    def fit(self, X, y):
        y = np.asarray(y); self.classes_ = np.unique(y)
        ratio = float((y == 0).sum() / max((y == 1).sum(), 1))
        self.model_ = XGBClassifier(n_estimators=self.n_estimators, max_depth=self.max_depth,
                                    learning_rate=self.learning_rate, scale_pos_weight=ratio,
                                    eval_metric='logloss', random_state=self.random_state,
                                    verbosity=0, n_jobs=-1).fit(X, y)
        return self
    def predict_proba(self, X): return self.model_.predict_proba(X)
    def predict(self, X): return self.model_.predict(X)

def xgb_model():
    return XGBPerFitRatio(random_state=RANDOM_STATE)
def svm_model():
    # probability=True would run an internal 5-fold Platt calibration on every
    # fit. The decision function is sigmoid-squashed downstream instead, exactly
    # as for Ridge, which is both faster and more consistent across models.
    return Pipeline([('sc', StandardScaler()),
                     ('m', SVC(kernel='rbf', class_weight='balanced',
                               C=1.0, random_state=RANDOM_STATE))])
def nms_model():
    return Pipeline([('sc', StandardScaler()),
                     ('lr', LogisticRegression(C=1.0, class_weight='balanced',
                                               max_iter=1000, random_state=RANDOM_STATE))])

HEAD = 'A1_Full_Signal+NMS'
CONFIGS = [(HEAD, ridge_raw, 'full', True)]
if RUN_ABLATION:
    CONFIGS += [
        ('A2_Signal_Only',        ridge_raw,    'full', False),
        ('A3_NMS_Only',           None,         None,   True),
        ('A4_MeanOnly_No_Std',    ridge_raw,    'mean', True),
        ('B0_Ridge_Scaled',       ridge_scaled, 'full', True),
        ('B1_LogisticRegression', lr_model,     'full', True),
        ('B2_RandomForest',       rf_model,     'full', True),
        ('B3_XGBoost',            xgb_model,    'full', True),
        ('B4_SVM_RBF',            svm_model,    'full', True),
    ]
CONFIG_NAMES = [c[0] for c in CONFIGS]

def scores_from(model_fn, X_tr, y_tr, X_te, inner_cv):
    """Fit; return (train OOF score, test score). Decision functions are sigmoid-squashed."""
    m = model_fn(); m.fit(X_tr, y_tr)
    if hasattr(m, 'decision_function'):
        oof = cross_val_predict(model_fn(), X_tr, y_tr, cv=inner_cv, method='decision_function')
        return 1 / (1 + np.exp(-oof)), 1 / (1 + np.exp(-m.decision_function(X_te)))
    oof = cross_val_predict(model_fn(), X_tr, y_tr, cv=inner_cv, method='predict_proba')[:, 1]
    return oof, m.predict_proba(X_te)[:, 1]

def nms_scores(X_tr, y_tr, X_te, inner_cv):
    """Questionnaire branch — predict_proba explicitly, exactly as in cell 81."""
    m = nms_model(); m.fit(X_tr, y_tr)
    oof = cross_val_predict(nms_model(), X_tr, y_tr, cv=inner_cv, method='predict_proba')[:, 1]
    return oof, m.predict_proba(X_te)[:, 1]


# ================================================================= DATA CHECKS
REF_DIR = '/content/drive/MyDrive/Parkinson/pads_final_6ch'      # saved main run
q_files = sorted(glob(f"{data_path}/**/questionnaire_response_*.json", recursive=True))
qmap = {}
for f in q_files:
    d = json.load(open(f)); qmap[str(d.get('subject_id'))] = d.get('item', [])
q_problems = []
for p in valid_pids:
    items = qmap.get(str(p))
    if items is None:
        q_problems.append((str(p), 'no questionnaire')); continue
    try:
        ids = sorted(int(it.get('link_id')) for it in items)
    except Exception:
        q_problems.append((str(p), 'non-numeric item id')); continue
    if ids != list(range(1, 31)):
        q_problems.append((str(p), f'item ids not exactly 1..30 (n={len(ids)}, unique={len(set(ids))})'))
    if any(not isinstance(it.get('answer'), bool) for it in items):
        q_problems.append((str(p), 'missing or non-boolean answer'))
seg_counts = {str(p): len(patient_segments[p]) for p in valid_pids}
bad_seg = {p: c for p, c in seg_counts.items() if c != 22}
print("\n" + "=" * 74)
print("DATA CHECKS")
print("=" * 74)
print(f"   participants: {len(valid_pids)}")
print(f"   participants without exactly 22 recordings: {len(bad_seg)} {list(bad_seg.items())[:5]}")
print(f"   questionnaire problems: {len(q_problems)} {q_problems[:5]}")

# ================================================================= XGBOOST RE-RUN
outer_cv = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_STATE)
inner_cv = StratifiedKFold(n_splits=5,       shuffle=True, random_state=RANDOM_STATE)
new = {'bal_acc': [], 'sens': [], 'spec': [], 'f1': [], 'auc': []}
for fold, (tr_idx, te_idx) in enumerate(outer_cv.split(valid_pids, pat_labels), 1):
    ck = f'{OUTPUT_DIR}/xgb_fold_{fold}.pkl'
    if os.path.exists(ck):
        v = pickle.load(open(ck, 'rb'))
        if v.get('signature') == RUN_SIGNATURE:
            for k in new: new[k].append(v[k])
            print(f"FOLD {fold}: from checkpoint | BA={v['bal_acc']*100:.2f}%"); continue
    t0 = time.time()
    tr_pids, te_pids = valid_pids[tr_idx], valid_pids[te_idx]
    y_tr, y_te = pat_labels[tr_idx], pat_labels[te_idx]
    tr_segs, tr_counts = segments_array(tr_pids); te_segs, te_counts = segments_array(te_pids)
    rocket = MiniRocketMultivariate(num_kernels=N_KERNELS, random_state=RANDOM_STATE, n_jobs=-1)
    R_tr = rocket.fit_transform(tr_segs); R_tr = R_tr.values if hasattr(R_tr, 'values') else np.array(R_tr)
    R_te = rocket.transform(te_segs);     R_te = R_te.values if hasattr(R_te, 'values') else np.array(R_te)
    del tr_segs, te_segs; gc.collect()
    X_tr = aggregate_patient(R_tr, tr_counts, True); X_te = aggregate_patient(R_te, te_counts, True)
    del R_tr, R_te; gc.collect()
    nms_oof, nms_te = nms_scores(pat_nms[tr_idx], y_tr, pat_nms[te_idx], inner_cv)
    sig_oof, sig_te = scores_from(xgb_model, X_tr, y_tr, X_te, inner_cv)
    oof = (sig_oof + nms_oof) / 2.0; te = (sig_te + nms_te) / 2.0
    th = youden_threshold(y_tr, oof); pred = (te >= th).astype(int)
    v = {'bal_acc': balanced_accuracy_score(y_te, pred),
         'sens': recall_score(y_te, pred, pos_label=1, zero_division=0),
         'spec': recall_score(y_te, pred, pos_label=0, zero_division=0),
         'f1': f1_score(y_te, pred, zero_division=0), 'auc': roc_auc_score(y_te, te),
         'signature': RUN_SIGNATURE}
    pickle.dump(v, open(ck, 'wb'))
    for k in new: new[k].append(v[k])
    print(f"FOLD {fold}/{N_FOLDS}: BA={v['bal_acc']*100:.2f}%  ({(time.time()-t0)/60:.1f} min)")

# ================================================================= TABLE 7 UPDATE
R = pickle.load(open(f'{REF_DIR}/raw_predictions.pkl', 'rb'))['results']
ba = lambda d: np.asarray(d['bal_acc'], float) * 100
ref = ba(R[HEAD]); xgb_new = np.asarray(new['bal_acc']) * 100
fam = {'B1_LogisticRegression': ba(R['B1_LogisticRegression']), 'B2_RandomForest': ba(R['B2_RandomForest']),
       'B3_XGBoost': xgb_new, 'B4_SVM_RBF': ba(R['B4_SVM_RBF'])}
Ws, ps = {}, {}
for n, v in fam.items():
    try: W, p = wilcoxon(ref, v)
    except Exception: W, p = float('nan'), 1.0
    Ws[n], ps[n] = float(W), float(p)
adj = dict(zip(fam, holm([ps[n] for n in fam])))
ms_ = lambda arr: (float(np.mean(arr) * 100), float(np.std(arr, ddof=0) * 100))
row = {k: ms_(np.asarray(new[k], float)) for k in ['bal_acc', 'sens', 'spec', 'f1', 'auc']}
old = {k: ms_(np.asarray(R['B3_XGBoost'][k], float)) for k in ['bal_acc', 'sens', 'spec', 'f1', 'auc']}
means = {'B0_Ridge_Scaled': ba(R['B0_Ridge_Scaled']).mean(), **{n: v.mean() for n, v in fam.items()}}
span = max(means.values()) - min(means.values())
print("\n" + "=" * 74)
print("TABLE 7 — XGBoost row (per-fit class ratio) and Holm over the four comparators")
print("=" * 74)
fmt = lambda d: '  '.join(f"{k}: {d[k][0]:.2f} ± {d[k][1]:.2f}" for k in d)
print("   old XGB row:", fmt(old))
print("   new XGB row:", fmt(row))
for n in fam:
    print(f"   {n:<24} BA {fam[n].mean():6.2f}  W = {Ws[n]:5.1f}  p = {ps[n]:.3f}  Holm p = {adj[n]:.3f}")
print(f"   A1 BA {ref.mean():.2f} | spread across B0-B4 means: {span:.2f} pp | "
      f"max {max(means, key=means.get)} {max(means.values()):.2f} | min {min(means, key=means.get)} {min(means.values()):.2f}")
out = {'data_checks': {'n': int(len(valid_pids)), 'not_22_recordings': bad_seg, 'questionnaire_problems': q_problems},
       'xgb_new': {'fold_metrics': {k: [float(x) for x in new[k]] for k in new}, 'row': row},
       'xgb_old_row': old, 'wilcoxon': Ws, 'p': ps, 'p_holm': adj,
       'means_B0_B4': {k: float(v) for k, v in means.items()}, 'spread_pp': float(span),
       'signature': RUN_SIGNATURE}
json.dump(out, open(f'{OUTPUT_DIR}/xgb_perfit_update.json', 'w'), indent=2, default=float)
print(f"\nSaved: {OUTPUT_DIR}/xgb_perfit_update.json")
