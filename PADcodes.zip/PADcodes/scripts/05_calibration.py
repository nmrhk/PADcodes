# =============================================================================
# 05_calibration.py
# Calibration of the pooled out-of-fold fused score: calibration slope from a
# logistic regression of the outcome on logit(score), and calibration-in-the-
# large as the intercept with the slope fixed at 1. Reads raw_predictions.pkl
# (seconds). Output: <RUN_DIR>/calibration_check.json
# =============================================================================
import os, json, pickle
import numpy as np

RUN_DIR = '/content/drive/MyDrive/Parkinson/pads_final_6ch'
try:
    from google.colab import drive
    if not os.path.ismount('/content/drive'):
        drive.mount('/content/drive')
except Exception as e:
    print(f"(not on Colab: {e})")

# ---------------------------------------------------------------- calibration
R = pickle.load(open(f'{RUN_DIR}/raw_predictions.pkl', 'rb'))
yA = np.asarray(R['all_true']).astype(float)
pA = np.clip(np.asarray(R['all_prob']).astype(float), 1e-6, 1 - 1e-6)
lp = np.log(pA / (1 - pA))

def _logit_fit(X, y, offset=None, iters=100):
    """Unpenalized logistic regression (Newton-Raphson)."""
    X = np.column_stack([np.ones(len(y))] + ([X] if X is not None else []))
    off = np.zeros(len(y)) if offset is None else offset
    b = np.zeros(X.shape[1])
    for _ in range(iters):
        eta = X @ b + off; mu = 1 / (1 + np.exp(-eta))
        W = mu * (1 - mu); g = X.T @ (y - mu); H = X.T @ (X * W[:, None]) + 1e-8 * np.eye(X.shape[1])
        step = np.clip(np.linalg.solve(H, g), -5, 5); b += step
        if np.max(np.abs(step)) < 1e-10: break
    return b

citl  = _logit_fit(None, yA, offset=lp)[0]          # slope fixed at 1: calibration-in-the-large
slope = _logit_fit(lp, yA)[1]                       # calibration slope
print("=" * 74)
print("CALIBRATION of the pooled out-of-fold fused score (n = 355)")
print("=" * 74)
print(f"   calibration-in-the-large (intercept) = {citl:+.3f}   (ideal 0)")
print(f"   calibration slope                    = {slope:.3f}    (ideal 1)")
out = {'calibration': {'intercept': float(citl), 'slope': float(slope)}}

json.dump(out, open(f'{RUN_DIR}/calibration_check.json', 'w'), indent=2)
print(f"Saved: {RUN_DIR}/calibration_check.json")
