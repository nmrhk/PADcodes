# =============================================================================
# 03_inner_refit_check.py
# Sensitivity of threshold selection to sharing the MiniRocket transformation
# across the inner splits. MiniRocket is refitted within every inner training
# split; the outer models and outer test-fold scores are taken unchanged from
# raw_predictions.pkl, so only the threshold changes. A checkpoint is written
# after every outer fold.
# Output: <OUT_DIR>/inner_refit_check.json
# =============================================================================
import os, json, pickle, time, gc, zipfile, subprocess
import numpy as np, pandas as pd
from glob import glob
from collections import Counter

RUN_DIR    = "/content/drive/MyDrive/Parkinson/pads_final_6ch"
OUT_DIR    = "/content/drive/MyDrive/Parkinson/pads_inner_refit"
EXTRACT    = "/content/pads_data_extracted"
ZIP_NAME   = "pads-parkinsons-disease-smartwatch-dataset-1.0.0.zip"

RANDOM_STATE = 42
N_CHANNELS   = 6
SEG_LEN      = 400
N_KERNELS    = 8000          # yayinlanan kosuyla ayni
N_FOLDS      = 10
INNER_FOLDS  = 5

# ----------------------------------------------------------------- kurulum
try:
    from sktime.transformations.panel.rocket import MiniRocketMultivariate
except Exception:
    subprocess.run(["pip", "-q", "install", "sktime"], check=False)
    from sktime.transformations.panel.rocket import MiniRocketMultivariate
from scipy.signal import detrend, resample
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import RidgeClassifierCV, LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (balanced_accuracy_score, recall_score, f1_score,
                             roc_auc_score, roc_curve)
try:
    from tqdm.auto import tqdm
except Exception:
    def tqdm(x, **k): return x

if not os.path.exists("/content/drive/MyDrive"):
    from google.colab import drive; drive.mount("/content/drive")
os.makedirs(OUT_DIR, exist_ok=True)

# ----------------------------------------------------------------- veri
def find_data():
    if os.path.isdir(EXTRACT) and len(glob(f"{EXTRACT}/**/patient_*.json", recursive=True)) > 100:
        return EXTRACT
    for z in (f"/content/drive/MyDrive/Parkinson/{ZIP_NAME}", f"/content/{ZIP_NAME}"):
        if os.path.exists(z):
            print(f"Zip aciliyor: {z}")
            with zipfile.ZipFile(z) as zf: zf.extractall(EXTRACT)
            return EXTRACT
    raise FileNotFoundError("PADS zip bulunamadi.")

data_path = find_data()

# --- etiketler: tam eslestirme, veri setinin kendi patient_*.json dosyalarindan
PD_C = {"parkinson", "parkinsons", "parkinson's",
        "parkinson disease", "parkinsons disease", "parkinson's disease"}
HC_C = {"healthy", "healthy control", "healthy controls", "control"}
def _norm(s): return " ".join(str(s).strip().lower().replace("\u2019", "'").split())
def label_of(c):
    c = _norm(c)
    return 1 if c in PD_C else (0 if c in HC_C else -1)

patient_info = {}
for pf in sorted(glob(f"{data_path}/**/patient_*.json", recursive=True)):
    try:
        d = json.load(open(pf)); pid = str(d.get('id', ''))
        lbl = label_of(d.get('condition', ''))
        if lbl >= 0 and pid: patient_info[pid] = lbl
    except Exception: pass
_npd = sum(patient_info.values()); _nhc = len(patient_info) - _npd
assert (_npd, _nhc) == (276, 79), f"beklenen 276/79, gelen {_npd}/{_nhc}"
print(f"Etiketler: PD={_npd}, HC={_nhc}")

# --- anket: 30 ikili madde
# NOT: yapisi yayinlanan kosu scriptindeki blogun birebir aynisi
# (subject_id + item/link_id/answer). Tahmin edilmis bir sema DEGIL.
nms_by_pid = {}
for f in sorted(glob(f"{data_path}/**/questionnaire_response_*.json", recursive=True)):
    try:
        qd = json.load(open(f)); pid = str(qd.get('subject_id', ''))
        if pid not in patient_info: continue
        ans = [0] * 30
        for it in qd.get('item', []):
            try:
                i = int(it.get('link_id', '99')) - 1
                if 0 <= i < 30: ans[i] = 1 if it.get('answer') else 0
            except Exception: pass
        nms_by_pid[pid] = np.array(ans, dtype=float)
    except Exception: pass
print(f"Anket: {len(nms_by_pid)} katilimci")
assert len(nms_by_pid) >= 355, (
    f"Anket okunamadi ({len(nms_by_pid)}). Dosya adi/semasi beklenenden farkli.")

# --- sinyaller (zaman sutunu dusurulur -> 6 kanal)
_SKIP = ("LICENSE", "README", "SHA256SUMS", "RECORDS")
s_files = sorted([f for f in glob(f"{data_path}/**/*.txt", recursive=True)
                  if not any(s in os.path.basename(f).upper() for s in _SKIP)])
patient_segments = {}
for fp in tqdm(s_files, desc="Segmentler", ncols=70):
    try:
        pid = os.path.basename(fp).split('_')[0]
        if pid not in patient_info: continue
        raw = pd.read_csv(fp, header=None).select_dtypes(include=[np.number]).values
        if len(raw) < 100 or raw.shape[1] != N_CHANNELS + 1: continue
        raw = raw[:, 1:][50:, :]
        raw = detrend(raw, axis=0)
        raw = resample(raw, SEG_LEN, axis=0)
        patient_segments.setdefault(pid, []).append(
            np.ascontiguousarray(raw.T, dtype=np.float32))
    except Exception: continue

pids = sorted([p for p in patient_segments if p in nms_by_pid])
y_all = np.array([patient_info[p] for p in pids])
nms_all = np.vstack([nms_by_pid[p] for p in pids])
n_seg = sum(len(patient_segments[p]) for p in pids)
assert (int((y_all == 1).sum()), int((y_all == 0).sum())) == (276, 79)
assert n_seg == 7810, f"beklenen 7810 segment, gelen {n_seg}"
print(f"{len(pids)} hasta | {n_seg} segment | {N_CHANNELS} kanal  [kontroller gecti]")

def segs_of(sub):
    segs, counts = [], []
    for p in sub:
        counts.append(len(patient_segments[p]))
        segs.extend(patient_segments[p])
    return np.array(segs, dtype=np.float32), counts

def agg(R, counts):
    fd = R.shape[1]
    X = np.zeros((len(counts), fd * 2), np.float32); i = 0
    for k, c in enumerate(counts):
        s = R[i:i + c]; X[k, :fd] = s.mean(0); X[k, fd:] = s.std(0); i += c
    return X

def ridge():  return RidgeClassifierCV(alphas=np.logspace(-3, 3, 10),
                                       class_weight='balanced')
def nmsmod(): return Pipeline([('sc', StandardScaler()),
                               ('lr', LogisticRegression(C=1.0, class_weight='balanced',
                                                         max_iter=1000,
                                                         random_state=RANDOM_STATE))])
def sig(x):   return 1.0 / (1.0 + np.exp(-x))
def youden(y, s):
    fpr, tpr, th = roc_curve(y, s)
    return float(th[np.argmax(tpr - fpr)])

# ----------------------------------------------------------------- referans
ref = pickle.load(open(f"{RUN_DIR}/raw_predictions.pkl", "rb"))
HF = ref['head_folds']
assert len(HF) == N_FOLDS
print(f"Yayinlanan kosu okundu: {N_FOLDS} kat, eski tau* = "
      f"{[round(float(h['th']), 3) for h in HF]}")

# ----------------------------------------------------------------- deney
outer = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_STATE)
inner = StratifiedKFold(n_splits=INNER_FOLDS, shuffle=True, random_state=RANDOM_STATE)
idx_all = np.arange(len(pids))

results = []
ck = f"{OUT_DIR}/inner_refit_ckpt.pkl"
if os.path.exists(ck):
    results = pickle.load(open(ck, "rb"))
    print(f"Checkpoint bulundu: {len(results)} kat hazir, devam ediliyor.")

t0 = time.time()
for f, (tr, te) in enumerate(outer.split(idx_all, y_all)):
    if f < len(results): continue
    ft = time.time()
    print(f"\nKAT {f+1}/{N_FOLDS}  (ic MiniRocket yeniden fit ediliyor)")
    y_tr = y_all[tr]
    oof = np.zeros(len(tr), dtype=float)

    for j, (itr, iva) in enumerate(inner.split(tr, y_tr)):
        gtr, gva = tr[itr], tr[iva]
        S_tr, c_tr = segs_of([pids[i] for i in gtr])
        S_va, c_va = segs_of([pids[i] for i in gva])
        mr = MiniRocketMultivariate(num_kernels=N_KERNELS,
                                    random_state=RANDOM_STATE, n_jobs=-1)
        R_tr = np.asarray(mr.fit_transform(S_tr))      # SADECE ic-egitim
        R_va = np.asarray(mr.transform(S_va))
        del S_tr, S_va; gc.collect()
        X_tr, X_va = agg(R_tr, c_tr), agg(R_va, c_va)
        del R_tr, R_va; gc.collect()

        m = ridge(); m.fit(X_tr, y_all[gtr])
        s_va = sig(m.decision_function(X_va))
        q = nmsmod(); q.fit(nms_all[gtr], y_all[gtr])
        p_va = q.predict_proba(nms_all[gva])[:, 1]
        oof[iva] = (s_va + p_va) / 2.0
        del X_tr, X_va; gc.collect()
        print(f"   ic bolme {j+1}/{INNER_FOLDS} bitti ({(time.time()-ft)/60:.1f} dk)")

    th_new = youden(y_tr, oof)
    h = HF[f]
    y_te, p_te = np.asarray(h['y_true']), np.asarray(h['y_prob'])
    def mets(th):
        yp = (p_te >= th).astype(int)
        return dict(th=float(th),
                    bal_acc=balanced_accuracy_score(y_te, yp) * 100,
                    sens=recall_score(y_te, yp, pos_label=1, zero_division=0) * 100,
                    spec=recall_score(y_te, yp, pos_label=0, zero_division=0) * 100,
                    f1=f1_score(y_te, yp, zero_division=0) * 100)
    row = {'fold': f + 1, 'old': mets(float(h['th'])), 'new': mets(th_new),
           'auc': roc_auc_score(y_te, p_te) * 100}
    results.append(row)
    pickle.dump(results, open(ck, "wb"))
    print(f"   tau*: {row['old']['th']:.3f} -> {row['new']['th']:.3f}   "
          f"BA: {row['old']['bal_acc']:.2f} -> {row['new']['bal_acc']:.2f}   "
          f"({(time.time()-ft)/60:.1f} dk)")

# ----------------------------------------------------------------- rapor
def col(key, which): return np.array([r[which][key] for r in results])
print("\n" + "=" * 78)
print("IC-KATMAN MINIROCKET YENIDEN FIT — ESIK SECIMI KARSILASTIRMASI")
print("=" * 78)
print(f"{'Kat':>4}{'tau* eski':>11}{'tau* yeni':>11}{'BA eski':>10}{'BA yeni':>10}"
      f"{'fark':>8}")
for r in results:
    print(f"{r['fold']:>4}{r['old']['th']:>11.3f}{r['new']['th']:>11.3f}"
          f"{r['old']['bal_acc']:>10.2f}{r['new']['bal_acc']:>10.2f}"
          f"{r['new']['bal_acc']-r['old']['bal_acc']:>+8.2f}")

print("\n" + "-" * 78)
print(f"{'Metrik':<18}{'yayinlanan':>14}{'ic-refit':>14}{'fark (pp)':>12}")
summary = {}
for k, lbl in [('bal_acc', 'Balanced acc'), ('sens', 'Sensitivity'),
               ('spec', 'Specificity'), ('f1', 'F1-score'), ('th', 'tau*')]:
    o, n = col(k, 'old'), col(k, 'new')
    summary[k] = {'old_mean': float(o.mean()), 'old_sd': float(o.std(ddof=0)),
                  'new_mean': float(n.mean()), 'new_sd': float(n.std(ddof=0)),
                  'delta': float(n.mean() - o.mean())}
    fmt = "{:>13.3f}" if k == 'th' else "{:>8.2f} \u00b1 {:>4.2f}"
    if k == 'th':
        print(f"{lbl:<18}{o.mean():>14.3f}{n.mean():>14.3f}{n.mean()-o.mean():>+12.3f}")
    else:
        print(f"{lbl:<18}{o.mean():>8.2f} \u00b1{o.std(ddof=0):>5.2f}"
              f"{n.mean():>8.2f} \u00b1{n.std(ddof=0):>5.2f}"
              f"{n.mean()-o.mean():>+12.2f}")

d = summary['bal_acc']['delta']
print("\n" + "=" * 78)
print("YORUM")
print("=" * 78)
if abs(d) < 0.5:
    print(f"  Balanced accuracy farki {d:+.2f} pp — ihmal edilebilir.")
    print("  Ic bolmelerde donusumu paylasmak esik secimini olculebilir sekilde")
    print("  iyimser yapmiyor. Methods'taki mevcut ifade oldugu gibi kalabilir;")
    print("  bu sayiyi ek olarak raporlamak hakemin sorusunu pesinen kapatir.")
else:
    print(f"  Balanced accuracy farki {d:+.2f} pp — ihmal edilebilir degil.")
    print("  Paylasilan donusum esik secimini etkiliyor. Bu durumda ya ic-refit")
    print("  varyanti ana sonuc yapilmali, ya da fark limitasyonlarda acikca")
    print("  raporlanmalidir.")

print("\nMAKALEYE GIRECEK CUMLE (Methods ya da Limitations):")
print(f"  Refitting MiniRocket separately within each inner training split, so that")
print(f"  inner-validation participants contribute to neither the transformation nor")
print(f"  the classifier, changed the mean selected threshold from "
      f"{summary['th']['old_mean']:.3f} to {summary['th']['new_mean']:.3f} and mean")
print(f"  balanced accuracy from {summary['bal_acc']['old_mean']:.2f}% to "
      f"{summary['bal_acc']['new_mean']:.2f}% ({d:+.2f} pp), indicating that sharing")
print(f"  the outer-fold transformation across inner splits had a "
      f"{'negligible' if abs(d) < 0.5 else 'measurable'} effect on")
print(f"  threshold selection.")

json.dump({'per_fold': results, 'summary': summary,
           'n_kernels': N_KERNELS, 'inner_folds': INNER_FOLDS,
           'runtime_min': (time.time() - t0) / 60},
          open(f"{OUT_DIR}/inner_refit_check.json", "w"), indent=2)
print(f"\nKaydedildi: {OUT_DIR}/inner_refit_check.json")
print(f"Toplam sure: {(time.time()-t0)/60:.1f} dk")