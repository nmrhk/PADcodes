# PADcodes

Analysis code for:

> Kahraman A, Özcan M, Aydın F. *Smartwatch Signals and a Non-Motor Symptom Questionnaire for Parkinson's Disease Detection: A Leakage-Controlled Ablation and Prevalence Analysis.* Submitted to the Journal of Medical Systems, 2026.

The pipeline combines smartwatch motion signals and the 30-item non-motor symptom questionnaire (NMSQuest) of the public PADS data set (276 Parkinson's disease, 79 healthy controls). The motion branch uses MiniRocket features aggregated per participant and a RidgeClassifierCV; the questionnaire branch uses logistic regression; the two scores are averaged with equal weights. Evaluation is participant-level stratified 10-fold cross-validation, with the decision threshold chosen by the Youden index on inner 5-fold out-of-fold scores of the training participants.

## Data

PADS — Parkinson's Disease Smartwatch dataset, version 1.0.0, PhysioNet: https://doi.org/10.13026/m0w9-zx22

Download `pads-parkinsons-disease-smartwatch-dataset-1.0.0.zip` and place it in Google Drive under `MyDrive/Parkinson/` (or adjust the paths at the top of each script). The data are not redistributed here.

## Environment

All analyses were run on a standard Google Colab CPU runtime (two virtual cores, 13.6 GB RAM, no GPU) with Python 3.13 and the package versions in `requirements.txt`. Every script runs as a single Colab cell; paste the file content into a cell and run it. Scripts mount Google Drive when available and fall back to local paths otherwise.

## Scripts and what they produce

| Script | Purpose | Runtime | Manuscript |
|---|---|---|---|
| `scripts/00_data_checks.py` | Participant counts, 22 recordings per participant, complete 30-item questionnaires, patient-record fields | seconds | Methods, Data set |
| `scripts/01_main_pipeline.py` | Headline result, ablation, classifier comparison, pooled metrics, bootstrap intervals, predictive values, figures; writes `results.json` and `raw_predictions.pkl` | ~1 h headline only, ~3 h with ablation | Tables 4–7, Figs. 2–4, Results |
| `scripts/02_dispersion_tests.py` | Levene, Fligner–Killeen, paired fold bootstrap and leave-one-fold-out for the specificity SD | seconds | Results, ablation |
| `scripts/03_inner_refit_check.py` | MiniRocket refitted within every inner split; effect on the selected thresholds | ~45 min | Results, inner-split refit |
| `scripts/04_sex_and_missed_cases.py` | Sex-only baseline, questionnaire without sexual-function items, within-sex discrimination, missed versus detected patients | 1–2 min | Results, Sex Imbalance and Missed Cases |
| `scripts/05_calibration.py` | Calibration slope and calibration-in-the-large of the fused score | seconds | Results, Fig. 2c |
| `scripts/06_xgboost_perfit_update.py` | XGBoost comparator with the class ratio computed within each fit; updated Holm adjustment | ~1 h | Table 7 |

Run `01_main_pipeline.py` first; scripts 02–06 read its `raw_predictions.pkl` from `MyDrive/Parkinson/pads_final_6ch/`.

## Reproducibility notes

* Participants are sorted by identifier and all splits use `random_state = 42`, so folds are identical across runs and scripts.
* MiniRocket is fitted on the training participants of each outer fold only. It is shared by the inner splits used for threshold selection; `03_inner_refit_check.py` quantifies the effect of refitting it within each inner split.
* `01_main_pipeline.py` writes a checkpoint after every outer fold and reuses it only if the run settings and package versions match.
* The XGBoost comparator computes its positive-class weight from the labels of each fit. Table 7 reports this version (`06_xgboost_perfit_update.py`); an earlier run had used the class ratio of the whole cohort.
* Bootstrap intervals resample the fixed pooled out-of-fold predictions and do not include refitting variability.
* Some console messages in scripts 02–04 are in Turkish; computations and outputs are unaffected.

## License

MIT (see `LICENSE`).
